package org.immport.flock.commons;

public class Marker {
	private String name;
	private int index;
	
	public Marker() {}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	};
}
