package org.immport.flock.commons;

public class FlockAdapterException extends Exception {

	public FlockAdapterException() {
		// TODO Auto-generated constructor stub
	}

	public FlockAdapterException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FlockAdapterException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public FlockAdapterException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
