package org.immport.flow.io;

import java.io.File;

/**
 * Methods for reading the binary version of the FCS file and the Population
 * File generated as part of the Flow Cytometry analysis using FLOCK.
 * 
 * @author BISC-Team
 */
public interface FlowFileReader {
    
    /**
     * Reads the FCS output file, to transform the file
     * into a 2 dimensional array representing the expression value
     * for each marker and each event
     * 
     * @param inputFile
     * @param numberOfEvents
     * @param numberOfMarkers
     * 
     * @return 2 dimensional array representing the output from Flow analysis
     */
    public int [][] readCoordinates(File inputFile, int numberOfEvents, int numberOfMarkers) throws Exception;
    
    /**
     * Reads the FCS population output file, to transform the file
     * into a 1 dimensional array representing the population assigned to each event
     * 
     * @param inputFile
     * @param numberOfEvents
     * 
     * @return 1 dimensional array representing the population assigned to each event
     */
    public int [] readPopulations(File inputFile, int numberOfEvents) throws Exception;

}