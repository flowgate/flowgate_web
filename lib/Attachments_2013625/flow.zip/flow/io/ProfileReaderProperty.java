package org.immport.flow.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.TreeMap;
import org.immport.flow.model.Marker;
import org.immport.flow.model.Population;

/**
 * Reads in the fcs.properties file and provides methods for reading and setting
 * values
 * 
 * @author BISC-Team
 * 
 */
public class ProfileReaderProperty {

    private int minValue;
    private int maxValue;
    private int numberOfEvents;
    private int numberOfMarkers;
    private int numberOfPopulations;
    private ArrayList<Marker> markers = new ArrayList<Marker>();
    private Properties properties = null;
    private TreeMap<Integer, Population> populationCounts = new TreeMap<Integer, Population>();

    /**
     * Reads and parses the fcs.properties file
     * 
     * @param propertyFile
     *            name of property file
     * @throws Exception
     */
    public void load(File propertyFile) throws Exception {
        properties = new Properties();
        try {
            properties.load(new FileInputStream(propertyFile));
            minValue = Integer.parseInt(properties.getProperty("Min"));
            maxValue = Integer.parseInt(properties.getProperty("Max"));
            numberOfEvents = Integer.parseInt(properties.getProperty("Events"));
            numberOfMarkers = Integer.parseInt(properties
                    .getProperty("Markers"));
            String populationsText = properties.getProperty("Populations");
            if (populationsText != null) {
                numberOfPopulations = Integer.parseInt(properties
                        .getProperty("Populations"));
            }
            String markerStr = properties.getProperty("MarkerNames");
            String[] markerNames = markerStr.split("\\|");
            for (int i = 0; i < markerNames.length; i++) {
                Marker m = new Marker();
                m.setPosition(i + 1);
                m.setName(markerNames[i]);
                m.setAssignedName(markerNames[i]);
                markers.add(m);
            }

            String populationsCountText = properties
                    .getProperty("PopulationCount");
            String[] popCounts = populationsCountText.split(",");

            int start = 1;
            int end = 0;
            for (int i = 0; i < popCounts.length; i++) {
                String[] values = popCounts[i].split(":");
                end = end + Integer.valueOf(values[1]);
                Population pop = new Population();
                int id = Integer.parseInt(values[0].replace("P", ""));
                pop.setId(id);
                pop.setStart(start);
                pop.setEnd(end);
                pop.setCount(Integer.valueOf(values[1]));
                start = end + 1;

                populationCounts.put(id, pop);
            }

        } catch (IOException ex) {
            throw new Exception("Unable to load the properties file");
        }
    }

    /**
     * Return the minimum expression value
     * 
     * @return minimum expression value
     */
    public int getMinValue() {
        return minValue;
    }

    /**
     * Set the minimum expression value
     * 
     * @param minValue
     *            minimum expression value
     */
    public void setMinValue(int minValue) {
        this.minValue = minValue;
    }

    /**
     * Return the maximum expression value
     * 
     * @return maximum expression value
     */
    public int getMaxValue() {
        return maxValue;
    }

    /**
     * Set the maximum expression value
     * 
     * @param maxValue
     *            maximum expression value
     */
    public void setMaxValue(int maxValue) {
        this.maxValue = maxValue;
    }

    /**
     * Return the number of events
     * 
     * @return the number of events
     */
    public int getNumberOfEvents() {
        return numberOfEvents;
    }

    /**
     * Set the number of events
     * 
     * @param numberOfEvents
     *            number of events
     */
    public void setNumberOfEvents(int numberOfEvents) {
        this.numberOfEvents = numberOfEvents;
    }

    /**
     * Return the number of markers
     * 
     * @return number of markers
     */
    public int getNumberOfMarkers() {
        return numberOfMarkers;
    }

    /**
     * Set the number of markers
     * 
     * @param numberOfMarkers
     *            number of markers
     */
    public void setNumberOfMarkers(int numberOfMarkers) {
        this.numberOfMarkers = numberOfMarkers;
    }

    /**
     * Return the number of populations
     * 
     * @return number of population
     */
    public int getNumberOfPopulations() {
        return numberOfPopulations;
    }

    /**
     * Set the number of populations
     * 
     * @param numberOfPopulations
     *            number of populations
     */
    public void setNumberOfPopulations(int numberOfPopulations) {
        this.numberOfPopulations = numberOfPopulations;
    }

    /**
     * Return an array of Marker objects
     * 
     * @return markers
     */
    public ArrayList<Marker> getMarkers() {
        return markers;
    }

    /**
     * Set an array of Marker objects
     * 
     * @param markers
     *            array of Marker objects
     */
    public void setMarkers(ArrayList<Marker> markers) {
        this.markers = markers;
    }

    /**
     * Return a map of populations and the count of events per population
     * 
     * @return map of populations and the count of events per population
     */
    public TreeMap<Integer, Population> getPopulationCounts() {
        return populationCounts;
    }

    /**
     * Set a map of populations and the count of events per population
     * 
     * @param populationCounts
     *            a TreeMap of populations and the count of events per
     *            population
     */
    public void setPopulationCounts(
            TreeMap<Integer, Population> populationCounts) {
        this.populationCounts = populationCounts;
    }

}