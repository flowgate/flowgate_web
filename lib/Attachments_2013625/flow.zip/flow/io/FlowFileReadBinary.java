package org.immport.flow.io;

import java.io.File;
import java.io.FileInputStream;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

/**
 * Methods for reading the binary version of the FCS file and the Population
 * File generated as part of the Flow Cytometry analysis using FLOCK.
 * 
 * @author BISC-Team
 */
public class FlowFileReadBinary implements FlowFileReader {

    /**
     * Reads the binary version of the FCS output file, to transform the file
     * into a 2 dimensional array representing the expression value
     * for each marker and event
     * 
     * @param inputFile
     * @param numberOfEvents
     * @param numberOfMarkers
     * 
     * @return 2 dimensional array representing the output from Flow analysis
     */
    public int[][] readCoordinates(File inputFile, int numberOfEvents,
            int numberOfMarkers) throws Exception {
        int[][] coordinates = new int[numberOfMarkers][numberOfEvents];

        FileInputStream expr = null;
        try {
            expr = new FileInputStream(inputFile);
            FileChannel exprChannel = expr.getChannel();
            int size = (int) exprChannel.size();
            MappedByteBuffer exprByteBuffer = exprChannel.map(
                    FileChannel.MapMode.READ_ONLY, 0, size);

            for (int i = 0; i < numberOfMarkers; i++) {
                exprByteBuffer.position(i * numberOfEvents * 4);
                exprByteBuffer.asIntBuffer().get(coordinates[i], 0,
                        numberOfEvents);
            }
        } catch (Exception ex) {
            System.err.println("EX: " + ex);
            throw new Exception();
        } finally {
            if (expr != null) {
                try {
                    expr.close();
                } catch (Exception ex) {
                }
            }
        }
        return coordinates;
    }

    /**
     * Reads the binary version of the FCS population output file, to transform the file
     * into a 1 dimensional array representing the population assigned to each event
     * 
     * @param inputFile
     * @param numberOfEvents
     * 
     * @return 1 dimensional array representing the population assigned to each event
     */
    public int[] readPopulations(File inputFile, int numberOfEvents)
            throws Exception {
        int[] populations = new int[numberOfEvents];

        FileInputStream expr = null;

        try {
            expr = new FileInputStream(inputFile);
            FileChannel exprChannel = expr.getChannel();
            int size = (int) exprChannel.size();
            MappedByteBuffer exprByteBuffer = exprChannel.map(
                    FileChannel.MapMode.READ_ONLY, 0, size);
            exprByteBuffer.asIntBuffer().get(populations, 0, numberOfEvents);
        } catch (Exception ex) {
            throw new Exception();
        } finally {
            if (expr != null) {
                try {
                    expr.close();
                } catch (Exception ex) {
                    // Nothing to do
                }
            }
        }
        return populations;
    }
}
