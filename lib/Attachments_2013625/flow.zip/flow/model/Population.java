package org.immport.flow.model;

/**
 * Represents a Flow Cytometry population.
 * 
 * @author BISC-Team
 */
public class Population {
    private int id;
    private String name;
    private int count;
    private int start;
    private int end;

    /**
     * Return the id assigned to this population
     * 
     * @return id assigned to this population
     */
    public int getId() {
        return id;
    }

    /**
     * Set the id assigned to this population
     * 
     * @param id id assigned to this population
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Return the name assigned to this population
     * 
     * @return name assigned to this population
     */
    public String getName() {
        return name;
    }

    /**
     * Set the name assigned to this population
     * 
     * @param name name assigned to this population
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Return the number of events assigned to this population
     * 
     * @return number of events assigned to this population
     */
    public int getCount() {
        return count;
    }

    /**
     * Set the number of events assigned to this population
     * 
     * @param count number of events assigned to this population
     */
    public void setCount(int count) {
        this.count = count;
    }

    /**
     * Return the starting position as an offset within the 
     * binary representation of the population file
     * 
     * @return starting position as an offset within the 
     * binary representation of the population file
     */
    public int getStart() {
        return start;
    }

    /**
     * Set the starting position as an offset within the
     * binary representation of the population file
     * 
     * @param start starting position as an offset within the
     * binary representation of the population file
     */
    public void setStart(int start) {
        this.start = start;
    }

    /**
     * Return the ending position as an offset within the
     * binary representation of the population file
     * 
     * @return ending position as an offset within the
     * binary representation of the population file
     */
    public int getEnd() {
        return end;
    }

    /**
     * Set the ending position as an offset within the
     * binary representation of the population file
     * 
     * @param end ending position as an offset within the
     * binary representation of the population file
     */
    public void setEnd(int end) {
        this.end = end;
    }
}