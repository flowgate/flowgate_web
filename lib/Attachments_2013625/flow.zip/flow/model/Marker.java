/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.immport.flow.model;

/**
 * Represents a Flow Cytometry marker. Properties include the original name,
 * assigned name and the column position within the expression value array.
 * 
 * @author BISC-Team
 */
public class Marker {
    private int position;
    private String name;
    private String assignedName;

    /**
     * Return the column position within an expression value array
     * 
     * @return column position within an expression value array
     */
    public int getPosition() {
        return position;
    }

    /**
     * Set the column position within an expression value array
     * 
     * @param column position within an expression value array
     */
    public void setPosition(int position) {
        this.position = position;
    }

    /**
     * Return the original name of the marker
     * 
     * @return original name of the marker
     */
    public String getName() {
        return name;
    }

    /**
     * Set the original name of a marker
     * @param name original name of a marker
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Return the user assigned name of a marker
     * 
     * @return user assigned name of a marker
     */
    public String getAssignedName() {
        return assignedName;
    }

    /**
     * Set the user assigned name of a marker
     * 
     * @param assignedName user assigned name of a marker
     */
    public void setAssignedName(String assignedName) {
        this.assignedName = assignedName;
    }

}
