/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.immport.flow.model;

import java.util.ArrayList;

import org.immport.flow.io.ProfileReaderProperty;

/**
 * Represents the data generated from a Flow Cytometry analysis
 * 
 * @author BISC-Team
 */
public class FlowData {
    private int[][] expressionValues;
    private int[][] scaledExpressionValues;
    private int[] populationAssignments;
    private int minValue;
    private int maxValue;
    private int numberOfEvents;
    private int numberOfMarkers;
    private int numberOfPopulations;
    private int scaleDimension = 0;
    private ArrayList<Marker> markers = null;
    private ArrayList<Population> populations = null;

    /**
     * Scales the expression values to a new range.
     * 
     * Requires the expressionValues, minValue, maxValue, numberOfMarkers and
     * numberOfPopulations should already be set before calling this method.
     * 
     * @param scaleDimension
     *            range to scale expression values. Normaly use 300 as the scale
     *            value.
     * @return 2 dimensional array of scaled expression values
     * 
     */
    public int[][] scaleExpressionValues(int scaleDimension) {
        // If they match then there is no reason to rescale
        if (scaleDimension == this.scaleDimension) {
            return scaledExpressionValues;
        }
        this.scaleDimension = scaleDimension;
        int range = maxValue - minValue + 1;
        scaledExpressionValues = new int[numberOfMarkers][getNumberOfEvents()];

        for (int i = 0; i < numberOfMarkers; i++) {
            for (int j = 0; j < numberOfEvents; j++) {
                float value = (float) expressionValues[i][j];
                scaledExpressionValues[i][j] = (int) (((value - minValue) * scaleDimension) / range);
            }
        }

        return scaledExpressionValues;
    }

    /**
     * Loads the properties from a fcs property file.
     * 
     * @param prp
     *            property file reader
     */
    public void loadProperties(ProfileReaderProperty prp) {
        this.numberOfEvents = prp.getNumberOfEvents();
        this.numberOfMarkers = prp.getNumberOfMarkers();
        this.numberOfPopulations = prp.getNumberOfPopulations();
        this.minValue = prp.getMinValue();
        this.maxValue = prp.getMaxValue();
        this.markers = prp.getMarkers();
    }

    /**
     * Returns a 2 dimensional array of expression values. The 1st dimension
     * corresponds to the events and the 2nd dimension to the markers.
     * 
     * @return 2 dimensional array of expression values
     */
    public int[][] getExpressionValues() {
        return expressionValues;
    }

    /**
     * Sets a 2 dimensional array of expression values. The 1st dimension
     * corresponds to the events and the 2nd dimension to the markers.
     * 
     * @param expressionValues
     *            2 dimensional array of expression values
     */
    public void setExpressionValues(int[][] expressionValues) {
        this.expressionValues = expressionValues;
    }

    /**
     * Returns a 2 dimensional array of scaled expression values. The 1st
     * dimension corresponds to the events and the 2nd dimension to the markers.
     * 
     * @return 2 dimensional array of scaled expression values
     * @return the scaledExpressionValues
     */
    public int[][] getScaledExpressionValues() {
        return scaledExpressionValues;
    }

    /**
     * Sets a 2 dimensional array of expression values. The 1st
     * dimension corresponds to the events and the 2nd dimension to the markers.
     * 
     * @param scaledExpressionValues
     *            2 dimensional array of scaled expression values
     */
    public void setScaledExpressionValues(int[][] scaledExpressionValues) {
        this.scaledExpressionValues = scaledExpressionValues;
    }

    /**
     * Returns the 1 dimensional array representing the population assigned to each event
     * 
     * @return 1 dimensional array representing the population assigned to each event
     */
    public int[] getPopulationAssignments() {
        return populationAssignments;
    }

    /**
     * Set the 1 dimensional array representing the population assigned to each event
     *  
     * @param populationAssignments
     *            1 dimensional array representing the population assigned to each event
     */
    public void setPopulationAssignments(int[] populationAssignments) {
        this.populationAssignments = populationAssignments;
    }

    /**
     * Returns the minimum expression value
     * 
     * @return minimum expression value
     */
    public int getMinValue() {
        return minValue;
    }

    /**
     * Set the minimum expression value
     * 
     * @param minValue minimum expression value
     */
    public void setMinValue(int minValue) {
        this.minValue = minValue;
    }

    /**
     * Returns the maximum expression value
     * 
     * @return maximum expression value
     */
    public int getMaxValue() {
        return maxValue;
    }

    /**
     * Set the maximum expression value
     * @param maxValue maximum expression value
     */
    public void setMaxValue(int maxValue) {
        this.maxValue = maxValue;
    }

    /**
     * Return the number of events
     * 
     * @return number of events
     */
    public int getNumberOfEvents() {
        return numberOfEvents;
    }

    /**
     * Set the number of events
     * 
     * @param numberOfEvents number of events
     */
    public void setNumberOfEvents(int numberOfEvents) {
        this.numberOfEvents = numberOfEvents;
    }

    /**
     * Return the number of markers
     * 
     * @return number of markers
     */
    public int getNumberOfMarkers() {
        return numberOfMarkers;
    }

    /**
     * Set the number of markers
     * 
     * @param number of markers
     */
    public void setNumberOfMarkers(int numberOfMarkers) {
        this.numberOfMarkers = numberOfMarkers;
    }

    /**
     * Return the number of populations
     * 
     * @return number of populations
     */
    public int getNumberOfPopulations() {
        return numberOfPopulations;
    }

    /**
     * Set the number of populations
     * 
     * @param number of populations
     */
    public void setNumberOfPopulations(int numberOfPopulations) {
        this.numberOfPopulations = numberOfPopulations;
    }

    /**
     * Return the scaling dimension
     * 
     * @return scaling dimension
     */
    public int getScaleDimension() {
        return scaleDimension;
    }

    /**
     * Set the scaling dimension
     * 
     * @param scaleDimension scaling dimension
     */
    public void setScaleDimension(int scaleDimension) {
        this.scaleDimension = scaleDimension;
    }

    /**
     * Return an array of Marker objects
     * 
     * @return array of Marker objects
     */
    public ArrayList<Marker> getMarkers() {
        return markers;
    }

    /**
     * Set the array of Marker objects
     * 
     * @param array of Marker objects
     */
    public void setMarkers(ArrayList<Marker> markers) {
        this.markers = markers;
    }

    /**
     * Return an array of Population objects
     * 
     * @return array of Population objects
     */
    public ArrayList<Population> getPopulations() {
        return populations;
    }

    /**
     * Set the array of Population objects
     * 
     * @param array of Population objects
     */
    public void setPopulatons(ArrayList<Population> populations) {
        this.populations = populations;
    }
}
