package org.immport.flow.image;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;

import org.apache.commons.io.IOUtils;

/**
 * Utility methods for writing image files to the file system
 * 
 * @author BISC-Team
 * 
 */
public class ImageUtils {

    /**
     * Writes BufferedImage to the file system
     * 
     * @param imageFile output file name
     * @param img BufferedImage
     * @throws Exception
     */
    public static void saveImage(File imageFile, BufferedImage img)
            throws Exception {
        byte[] points = getImageAsByteArray(img);
        writeToFile(imageFile, new ByteArrayInputStream(points));
    }

    /**
     * Transform a BufferedImage to a byte array
     * 
     * @param img BufferedImage
     * @return byte array representing the images
     * @throws IOException
     */
    private static byte[] getImageAsByteArray(BufferedImage img)
            throws IOException {
        ByteArrayOutputStream image = new ByteArrayOutputStream();
        ImageIO.write(img, "png", image);
        image.close();
        return image.toByteArray();
    }

    /**
     * Write an InputStream representing an image to the output file
     * 
     * @param imageFile output file
     * @param is InputStream
     * @throws Exception
     */
    public static void writeToFile(File imageFile, InputStream is)
            throws Exception {
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(imageFile);
            IOUtils.copy(is, fos);
            fos.close();
        } catch (FileNotFoundException ex) {
            System.out.println("Ex: " + ex);
        } catch (IOException ex) {
            System.out.println("Ex: " + ex);
        } finally {
            try {
                if (fos != null) {
                    fos.close();
                }
            } catch (IOException ex) {
                System.out.println("Ex: " + ex);
            }
        }
    }
}
