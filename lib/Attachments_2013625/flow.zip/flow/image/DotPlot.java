package org.immport.flow.image;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import org.immport.flow.model.FlowData;
import org.immport.flow.model.Population;

/**
 * Generates dot plot images generated from Flow Cytometry analysis
 * 
 * @author BISC-Team
 *
 */
public class DotPlot {

    private FlowData flowData = null;

    /**
     * Retrieves the FlowData object
     * 
     * @return FlowData
     */
    public FlowData getFlowData() {
        return flowData;
    }

    /**
     * Sets the FlowData object
     * 
     * @param flowData
     */
    public void setFlowData(FlowData flowData) {
        this.flowData = flowData;
    }

    /**
     * Generates PNG images for all the marker combinations
     * 
     * @param directory location for image output
     * @param dimension scaling of the images, generally 300
     * @param transparent whether the image should have a transparent background
     * @param bw indicates if image should be in black and white or color
     */
    public void writeOverViewImages(String directory, int dimension,
            boolean transparent, boolean bw) {
        int numberOfMarkers = flowData.getNumberOfMarkers();
        if (dimension != flowData.getScaleDimension()) {
            flowData.scaleExpressionValues(dimension);
        }

        try {
            for (int i = 0; i < numberOfMarkers; i++) {
                for (int j = 0; j < numberOfMarkers; j++) {
                    String name1 = "m" + i;
                    String name2 = "m" + j;
                    String imageName = null;
                    if (bw) {
                        imageName = name1 + "." + name2 + ".all.bw.png";
                    } else {
                        imageName = name1 + "." + name2 + ".all.color.png";
                    }
                    BufferedImage img = markerByMarkerAll(dimension,
                            transparent, bw, i, j);
                    ImageUtils.saveImage(new File(directory + "/" + imageName),
                            img);
                }
            }
        } catch (Exception ex) {
            System.out.println("Ex: " + ex);
        }
    }

    /**
     * 
     * Generates PNG images for all the marker combinations for a set of population
     * 
     * @param directory location for image output
     * @param dimension scaling of the images, generally 300
     * @param transparent whether the image should have a transparent background
     * @param bw indicates if image should be in black and white or color
     * @param pops set of populations to include in the images
     */
    public void writeOverViewImagesPop(String directory, int dimension,
            boolean transparent, boolean background,
            HashMap<Integer, Integer> pops) {
        int numberOfMarkers = flowData.getNumberOfMarkers();
        if (dimension != flowData.getScaleDimension()) {
            flowData.scaleExpressionValues(dimension);
        }

        try {
            for (int i = 0; i < numberOfMarkers; i++) {
                for (int j = 0; j < numberOfMarkers; j++) {
                    String name1 = "m" + i;
                    String name2 = "m" + j;
                    String imageName = null;
                    imageName = name1 + "." + name2 + ".overview.pop.color.png";
                    BufferedImage img = markerByMarkerPop(dimension,
                            transparent, background, i, j, pops);
                    ImageUtils.saveImage(new File(directory + "/" + imageName),
                            img);
                }
            }
        } catch (Exception ex) {
            System.out.println("Ex: " + ex);
        }
    }

    /**
     *
     * Generates one PNG image for all the marker combinations
     * 
     * @param directory location for image output
     * @param dimension scaling of the images, generally 300
     * @param transparent whether the image should have a transparent background
     * @param bw indicates if image should be in black and white or color
     * 
     */
    public void writeOverViewImage(String directory, int dimension,
            boolean transparent, boolean bw) {
        int numberOfMarkers = flowData.getNumberOfMarkers();
        if (dimension != flowData.getScaleDimension()) {
            flowData.scaleExpressionValues(dimension);
        }

        BufferedImage img = null;
        int largeDimension = numberOfMarkers * dimension;
        if (transparent) {
            img = new BufferedImage(largeDimension, largeDimension,
                    BufferedImage.TYPE_INT_ARGB);
        } else {
            img = new BufferedImage(largeDimension, largeDimension,
                    BufferedImage.TYPE_INT_RGB);
        }

        Graphics2D g2d = img.createGraphics();
        if (!transparent) {
            g2d.setColor(Color.LIGHT_GRAY);
            g2d.fillRect(0, 0, largeDimension, largeDimension);
        }

        String imageName = null;
        if (bw) {
            imageName = "overview.all.bw.png";
        } else {
            imageName = "overview.all.color.png";
        }
        try {
            for (int i = 0; i < numberOfMarkers; i++) {
                for (int j = 0; j < numberOfMarkers; j++) {
                    int xOffset = j * dimension;
                    int yOffset = i * dimension;
                    BufferedImage imgChild = markerByMarkerAll(dimension,
                            transparent, bw, i, j);
                    g2d.drawImage(imgChild, xOffset, yOffset, null);
                }
            }
            ImageUtils.saveImage(new File(directory + "/" + imageName), img);
        } catch (Exception ex) {
            System.out.println("Ex: " + ex);
        }
    }

    /**
     * 
     * Generates one PNG image for all populations for 2 markers
     * 
     * @param directory location for image output
     * @param dimension scaling of the images, generally 300
     * @param transparent whether the image should have a transparent background
     * @param withBackground whether to include white background of all events
     * @param marker1 x axis marker
     * @param marker2 y axis marker
     */
    public void writeMarkerByMarkerAllPopsImage(String directory,
            int dimension, boolean transparent, boolean withBackground,
            int marker1, int marker2) {
        int numberOfPopulations = flowData.getNumberOfPopulations();
        if (dimension != flowData.getScaleDimension()) {
            flowData.scaleExpressionValues(dimension);
        }

        BufferedImage img = null;
        int largeDimension = (numberOfPopulations + 1) * dimension;
        if (transparent) {
            img = new BufferedImage(dimension, largeDimension,
                    BufferedImage.TYPE_INT_ARGB);
        } else {
            img = new BufferedImage(dimension, largeDimension,
                    BufferedImage.TYPE_INT_RGB);
        }

        Graphics2D g2d = img.createGraphics();
        if (!transparent) {
            g2d.setColor(Color.LIGHT_GRAY);
            g2d.fillRect(0, 0, dimension, largeDimension);
        }

        String name1 = "m" + marker1;
        String name2 = "m" + marker2;
        String imageName = name1 + "." + name2 + ".populations.png";
        ArrayList<Population> populations = flowData.getPopulations();
        try {
            int popCount = 0;
            for (Population pop : populations) {
                int popId = pop.getId();
                int yOffset = popCount * dimension;
                popCount++;
                HashMap<Integer, Integer> popHash = new HashMap<Integer, Integer>();
                popHash.put(popId, 1);
                BufferedImage imgChild = markerByMarkerPop(dimension,
                        transparent, withBackground, marker1, marker2, popHash);
                g2d.drawImage(imgChild, 0, yOffset, null);
            }

            BufferedImage imgChild = background(dimension, transparent, false,
                    marker1, marker2);
            int yOffset = popCount * dimension;
            g2d.drawImage(imgChild, 0, yOffset, null);

            ImageUtils.saveImage(new File(directory + "/" + imageName), img);
        } catch (Exception ex) {
            System.out.println("Ex: " + ex);
        }

    }

    /**
     *
     * Generates individual PNG images for all populations for 2 markers
     * 
     * @param directory location for image output
     * @param dimension scaling of the images, generally 300
     * @param transparent whether the image should have a transparent background
     * @param withBackground whether to include white background of all events
     * @param marker1 x axis marker
     * @param marker2 y axis marker
     * 
     */
    public void writeMarkerByMarkerAllPopsImages(String directory,
            int dimension, boolean transparent, boolean withBackground,
            int marker1, int marker2) {
        if (dimension != flowData.getScaleDimension()) {
            flowData.scaleExpressionValues(dimension);
        }

        ArrayList<Population> populations = flowData.getPopulations();
        try {
            for (Population pop : populations) {
                int popId = pop.getId();
                HashMap<Integer, Integer> popHash = new HashMap<Integer, Integer>();
                popHash.put(popId, 1);
                BufferedImage img = markerByMarkerPop(dimension, transparent,
                        withBackground, marker1, marker2, popHash);
                String name1 = "m" + marker1;
                String name2 = "m" + marker2;
                String imageName = name1 + "." + name2 + "." + popId
                        + ".color.highlighted.png";
                ImageUtils
                        .saveImage(new File(directory + "/" + imageName), img);
            }
        } catch (Exception ex) {
            System.out.println("Ex: " + ex);
        }
    }

    /**
     * Generates a BufferedImage for 2 markers
     * 
     * @param dimension scaling of the images, generally 300
     * @param transparent whether the image should have a transparent background
     * @param bw indicates if image should be in black and white or color
     * @param marker1 x axis marker
     * @param marker2 y axis marker
     * 
     * @return the BufferImage for the dot plot
     */
    public BufferedImage markerByMarkerAll(int dimension, boolean transparent,
            boolean bw, int marker1, int marker2) {
        BufferedImage img = null;
        if (transparent) {
            img = new BufferedImage(dimension, dimension,
                    BufferedImage.TYPE_INT_ARGB);
        } else {
            img = new BufferedImage(dimension, dimension,
                    BufferedImage.TYPE_INT_RGB);
        }

        Graphics2D g2d = img.createGraphics();
        if (!transparent) {
            g2d.setColor(Color.LIGHT_GRAY);
            g2d.fillRect(0, 0, dimension, dimension);
        }

        Color[][] imageMatrix = genImageMatrix(dimension, marker1, marker2);
        drawImageMatrix(g2d, dimension, imageMatrix, bw);
        return img;
    }

    /**
     * Generates a BufferedImage for 2 markers representing all events
     * 
     * @param dimension scaling of the images, generally 300
     * @param transparent whether the image should have a transparent background
     * @param bw indicates if image should be in black and white or color
     * @param marker1 x axis marker
     * @param marker2 y axis marker
     * 
     * @return the BufferImage for the dot plot
     */
    public BufferedImage background(int dimension, boolean transparent,
            boolean bw, int marker1, int marker2) {
        Color[][] imageMatrix = genImageMatrixBackground(dimension, marker1,
                marker2, Color.WHITE);
        BufferedImage img = null;
        if (transparent) {
            img = new BufferedImage(dimension, dimension,
                    BufferedImage.TYPE_INT_ARGB);
        } else {
            img = new BufferedImage(dimension, dimension,
                    BufferedImage.TYPE_INT_RGB);
        }
        Graphics2D g2d = img.createGraphics();

        if (!transparent) {
            g2d.setColor(Color.LIGHT_GRAY);
            g2d.fillRect(0, 0, dimension, dimension);
        }

        drawImageMatrix(g2d, dimension, imageMatrix, false);
        return img;
    }

    /**
     * Generates BufferedImage images for 2 markers and a set of populations
     * 
     * @param dimension scaling of the images, generally 300
     * @param transparent whether the image should have a transparent background
     * @param withBackground whether to include white background of all events
     * @param marker1 x axis marker
     * @param marker2 y axis marker
     * @param populations a set of populations
     */
    public BufferedImage markerByMarkerPop(int dimension, boolean transparent,
            boolean withBackground, int marker1, int marker2,
            HashMap<Integer, Integer> populations) {
        BufferedImage img = null;
        if (transparent) {
            img = new BufferedImage(dimension, dimension,
                    BufferedImage.TYPE_INT_ARGB);
        } else {
            img = new BufferedImage(dimension, dimension,
                    BufferedImage.TYPE_INT_RGB);
        }

        Graphics2D g2d = img.createGraphics();
        if (!transparent) {
            g2d.setColor(Color.LIGHT_GRAY);
            g2d.fillRect(0, 0, dimension, dimension);
        }

        if (withBackground) {
            Color[][] imageMatrix = genImageMatrixBackground(dimension,
                    marker1, marker2, Color.WHITE);
            drawImageMatrix(g2d, dimension, imageMatrix, false);
        }
        Color[][] imageMatrix = genImageMatrixUsePop(dimension, marker1,
                marker2, populations);
        drawImageMatrix(g2d, dimension, imageMatrix, false);
        return img;
    }

    /**
     * Draw the matrix on the Graphics2D
     * 
     * @param g2d graphics object
     * @param dimension scaling of the images, generally 300
     * @param imageMatrix matrix of the population at each point
     * @param bw indicates if image should be in black and white or color
     */
    private void drawImageMatrix(Graphics2D g2d, int dimension,
            Color[][] imageMatrix, boolean bw) {
        for (int k = 0; k < dimension; k++) {
            for (int l = 0; l < dimension; l++) {
                if (imageMatrix[k][l] != null) {
                    if (bw) {
                        g2d.setColor(Color.BLACK);
                    } else {
                        g2d.setColor(imageMatrix[k][l]);
                    }
                    g2d.drawLine(k, l, k, l);
                }
            }
        }
    }

    /**
     * Generates a matrix representing all populations for 2 markers
     *
     * @param dimension scaling of the images, generally 300
     * @param marker1 x axis marker
     * @param marker2 y axis marker
     * 
     * @return matrix representing the population for each x/y coordinate
     */
    private Color[][] genImageMatrix(int dimension, int marker1, int marker2) {
        Color[][] imageMatrix = new Color[dimension][dimension];
        int events = flowData.getNumberOfEvents();
        int[][] coordinates = flowData.getScaledExpressionValues();
        int[] populations = flowData.getPopulationAssignments();

        for (int i = 0; i < events; i++) {
            int x = coordinates[marker1][i];
            int y = dimension - coordinates[marker2][i];

            Color c = ColorUtils.getColor(populations[i]);

            if (x == dimension) {
                x = dimension - 1;
            }
            if (y == dimension) {
                y = dimension - 1;
            }

            imageMatrix[x][y] = c;
        }
        return imageMatrix;
    }

    /**
     * Generates image matrix using only the selected populations for 2 markers
     * 
     * @param dimension scaling of the images, generally 300
     * @param marker1 x axis marker
     * @param marker2 y axis marker
     * @param pops set of populations
     * 
     * @return matrix representing the population for each x/y coordinate
     */
    private Color[][] genImageMatrixUsePop(int dimension, int idx1, int idx2,
            HashMap<Integer, Integer> pops) {
        Color[][] imageMatrix = new Color[dimension][dimension];
        int events = flowData.getNumberOfEvents();
        int[][] coordinates = flowData.getScaledExpressionValues();
        int[] populations = flowData.getPopulationAssignments();

        for (int i = 0; i < events; i++) {
            if (pops.containsKey(populations[i])) {
                int x = coordinates[idx1][i];
                int y = dimension - coordinates[idx2][i];

                Color c = ColorUtils.getColor(populations[i]);

                if (x == dimension) {
                    x = dimension - 1;
                }
                if (y == dimension) {
                    y = dimension - 1;
                }

                imageMatrix[x][y] = c;
            }
        }
        return imageMatrix;
    }

    /**
     * Generates a background matrix representing all the populations for 2 markers
     *
     * @param dimension scaling of the images, generally 300
     * @param marker1 x axis marker
     * @param marker2 y axis marker
     * @param color Color object almost always WHITE.
     *
     * @return  matrix representing an event present or absent for each x/y coordinate
     */
    private Color[][] genImageMatrixBackground(int dimension, int marker1,
            int marker2, Color color) {
        Color[][] imageMatrix = new Color[dimension][dimension];
        int events = flowData.getNumberOfEvents();
        int[][] coordinates = flowData.getScaledExpressionValues();

        for (int i = 0; i < events; i++) {
            int x = coordinates[marker1][i];
            int y = dimension - coordinates[marker2][i];

            if (x == dimension) {
                x = dimension - 1;
            }
            if (y == dimension) {
                y = dimension - 1;
            }

            imageMatrix[x][y] = color;
        }

        return imageMatrix;
    }
}
