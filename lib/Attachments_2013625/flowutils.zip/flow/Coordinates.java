package org.immport.struts.utils.flow;

/**
 * The Coordinates Class
 *
 * @author BISC-Team
 */
public class Coordinates {

	/**
	 * Instantiates new coordinates.
	 *
	 * @param _id1 the _id1
	 * @param _id2 the _id2
	 */
	Coordinates(String _id1, String _id2) {
		id1 = _id1;
		id2 = _id2;
	}

	/** The id1 and id2 string. */
	private String id1, id2;

	/**
	 * Gets the id1.
	 *
	 * @return the id1
	 */
	public String getId1() {
		return id1;
	}

	/**
	 * Gets the id2.
	 *
	 * @return the id2
	 */
	public String getId2() {
		return id2;
	}

}
