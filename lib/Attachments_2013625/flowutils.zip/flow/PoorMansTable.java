package org.immport.struts.utils.flow;

import java.io.*;
import java.util.Date;
import java.util.Properties;

/**
 * The Class PoorMansTable.
 *
 * @author BISC-Team
 */
public class PoorMansTable {

    /** The output dir. */
    private File outputDir;

    /**
     * Instantiates a new poor mans table.
     * 
     * @param outputDir
     *            the output dir
     */
    public PoorMansTable(File outputDir) {
        this.outputDir = outputDir;
        try {
            if (!new File(outputDir, "props").exists()) {
                props.store(new FileOutputStream(new File(outputDir, "props")),
                        "last update at " + new Date());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /** The props. */
    private Properties props = new Properties();

    /**
     * Save population marker expression.
     * 
     * @param pid
     *            the pid
     * @param population
     *            the population
     * @param markerExpression
     *            the marker expression
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    public void savePopulationMarkerExpression(long pid, int population,
            String markerExpression) throws IOException {
        FileInputStream fisIn = null;
        FileOutputStream fisOut = null;
        try {
            fisIn = new FileInputStream(new File(outputDir, "props"));
            // props.load(/*new FileReader*/new FileInputStream(new
            // File(outputDir, "props")));
            props.load(fisIn);
            fisIn.close();
            props
                    .setProperty("markerExpression" + population,
                            markerExpression);
            fisOut = new FileOutputStream(new File(outputDir, "props"));
            // props.store(/*new FileWriter*/new FileOutputStream(new
            // File(outputDir, "props")),
            // "last update at " + new Date());
            props.store(fisOut, "last update at " + new Date());
            fisOut.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fisIn != null) {
                fisIn.close();
            }
            if (fisOut != null) {
                fisOut.close();
            }
        }
    }

    /**
     * Save population cell type.
     * 
     * @param pid
     *            the pid
     * @param population
     *            the population
     * @param cellType
     *            the cell type
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    public void savePopulationCellType(long pid, int population, String cellType)
            throws IOException {
        FileInputStream fisIn = null;
        FileOutputStream fisOut = null;
        try {
            fisIn = new FileInputStream(new File(outputDir, "props"));
            props.load(fisIn);
            // props.load(/*new FileReader*/new FileInputStream(new
            // File(outputDir, "props")));
            fisIn.close();
            props.setProperty("cellType" + population, cellType);
            fisOut = new FileOutputStream(new File(outputDir, "props"));
            // props.store(/*new FileWriter*/new FileOutputStream(new
            // File(outputDir, "props")),
            // "last update at " + new Date());
            props.store(fisOut, "last update at " + new Date());
            fisOut.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fisIn != null) {
                fisIn.close();
            }
            if (fisOut != null) {
                fisOut.close();
            }
        }
    }

    /**
     * Load population marker expression.
     * 
     * @param pid
     *            the pid
     * @param population
     *            the population
     * @return the string
     * @throws FileNotFoundException
     *             the file not found exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    public String loadPopulationMarkerExpression(long pid, int population)
            throws FileNotFoundException, IOException {
        FileInputStream fisIn = null;
        try {
            fisIn = new FileInputStream(new File(outputDir, "props"));
            props.load(fisIn);
            // props.load(/*new FileReader*/new FileInputStream(new
            // File(outputDir, "props")));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fisIn != null) {
                fisIn.close();
            }
        }
        return props.getProperty("markerExpression" + population);
    }

    /**
     * Load population cell type.
     * 
     * @param pid
     *            the pid
     * @param population
     *            the population
     * @return the string
     * @throws FileNotFoundException
     *             the file not found exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    public String loadPopulationCellType(long pid, int population)
            throws FileNotFoundException, IOException {
        FileInputStream fisIn = null;
        try {
            fisIn = new FileInputStream(new File(outputDir, "props"));
            props.load(fisIn);
            // props.load(/*new FileReader*/new FileInputStream(new
            // File(outputDir, "props")));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fisIn != null) {
                fisIn.close();
            }
        }
        return props.getProperty("cellType" + population);

    }
}
