package org.immport.struts.utils.flow;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Convert task to binary format.
 *
 * @author BISC-Team
 */
public class ConvertTaskToBinary {

    /**
     * Instantiates a new convert task to binary.
     */
    public ConvertTaskToBinary() {
    }

    /**
     * Gets the events count.
     * 
     * @param inputDir
     *            the input dir
     * @return the events count
     * @throws Exception
     *             the exception
     */
    private int getEventsCount(File inputDir) throws Exception {
        BufferedReader br = null;
        int count = 0;
        try {
            br = new BufferedReader(new FileReader(new File(inputDir,
                    "population_id.txt")));
            while (br.readLine() != null) {
                count++;
            }
        } catch (IOException e) {
            throw new Exception(e);
        } finally {
            try {
                if (br != null) {
                    br.close();
                }
            } catch (IOException e) {
                throw new Exception(e);
            }
        }
        return count;
    }

    /**
     * Gets the parameters.
     * 
     * @param inputDir
     *            the input dir
     * @return the parameters
     * @throws Exception
     *             the exception
     */
    private String[] getParameters(File inputDir) throws Exception {
        BufferedReader br = null;
        String line;
        /*
         * 0 = Min 1 = Max 2 = bins 3 = density
         */
        String[] parameters = new String[4];
        try {
            br = new BufferedReader(new FileReader(new File(inputDir,
                    "parameters.txt")));

            while ((line = br.readLine()) != null) {
                String[] tokens = line.split("\t");
                if (tokens[0].equals("Min")) {
                    parameters[0] = tokens[1];
                }
                if (tokens[0].equals("Max")) {
                    parameters[1] = tokens[1];
                }
                if (tokens[0].equals("Number_of_Bins")) {
                    parameters[2] = tokens[1];
                }
                if (tokens[0].equals("Density")) {
                    parameters[3] = tokens[1];
                }
            }
        } catch (IOException e) {
            throw new FlockAdapterException(e);
        } finally {
            try {
                if (br != null) {
                    br.close();
                }
            } catch (IOException e) {
                throw new FlockAdapterException(e);
            }
        }
        return parameters;
    }

    /**
     * Gets the marker names.
     * 
     * @param inputDir
     *            the input dir
     * @return the marker names
     * @throws Exception
     *             the exception
     */
    private ArrayList<String> getMarkerNames(File inputDir) throws Exception {
        BufferedReader br = null;
        String line;
        ArrayList<String> markers = new ArrayList<String>();
        try {
            br = new BufferedReader(new FileReader(new File(inputDir,
                    "profile.txt")));
            line = br.readLine();
            String[] markerNames = line.split("\t");
            for (int i = 1; i < markerNames.length; i++) {
                markerNames[i] = markerNames[i].replace(">", "");
                markerNames[i] = markerNames[i].replace("<", "");

                markers.add(markerNames[i]);
            }

        } catch (IOException e) {
            throw new FlockAdapterException(e);
        } finally {
            try {
                if (br != null) {
                    br.close();
                }
            } catch (IOException e) {
                throw new FlockAdapterException(e);
            }
        }
        return markers;
    }

    /**
     * Gets the population count.
     * 
     * @param inputDir
     *            the input dir
     * @return the population count
     * @throws Exception
     *             the exception
     */
    private int getPopulationCount(File inputDir) throws Exception {
        BufferedReader br = null;
        String line;
        int populationCount = 0;
        ArrayList<String> markers = new ArrayList<String>();
        try {
            br = new BufferedReader(new FileReader(new File(inputDir,
                    "profile.txt")));
            line = br.readLine();
            while ((line = br.readLine()) != null) {
                populationCount++;
            }

        } catch (IOException e) {
            throw new FlockAdapterException(e);
        } finally {
            try {
                if (br != null) {
                    br.close();
                }
            } catch (IOException e) {
                throw new FlockAdapterException(e);
            }
        }
        return populationCount;
    }

    /**
     * Gen population bin.
     * 
     * @param inputDir
     *            the input dir
     * @throws Exception
     *             the exception
     */
    private void genPopulationBin(File inputDir) throws Exception {

        BufferedReader popReader = null;
        DataOutputStream binFile = null;

        try {
            String line;
            binFile = new DataOutputStream(new FileOutputStream(inputDir
                    + "/population.bin"));
            popReader = new BufferedReader(new FileReader(inputDir
                    + "/population_id.txt"));
            while ((line = popReader.readLine()) != null) {
                int v = Integer.valueOf(line);
                binFile.writeInt(v);
            }
            binFile.close();
        } catch (Exception ex) {
            System.out.println("EX: " + ex);
            throw new Exception("Problem generating the population.bin file");
        } finally {
            if (popReader != null) {
                try {
                    popReader.close();
                } catch (IOException e) {

                }
            }
            if (binFile != null) {
                try {
                    binFile.close();
                } catch (IOException e) {

                }
            }
        }
    }

    /**
     * Gen fcs bin.
     * 
     * @param inputDir
     *            the input dir
     * @param markers
     *            the markers
     * @param events
     *            the events
     * @throws Exception
     *             the exception
     */
    private void genFcsBin(File inputDir, int markers, int events)
            throws Exception {

        BufferedReader fcsReader = null;
        DataOutputStream binFile = null;

        try {
            int[][] values = new int[markers][events];
            int min = 99999999;
            int max = -99999999;
            int count = 0;
            String line;
            fcsReader = new BufferedReader(
                    new FileReader(inputDir + "/fcs.txt"));
            fcsReader.readLine();
            while ((line = fcsReader.readLine()) != null) {
                String[] data = line.split("\t");
                for (int i = 0; i < markers; i++) {
                    String value = data[i];
                    // int v = Integer.valueOf(value);
                    int v = (int) Float.parseFloat(value);
                    if (v > max) {
                        max = v;
                    }
                    if (v < min) {
                        min = v;
                    }
                    values[i][count] = v;
                }
                count++;
            }

            binFile = new DataOutputStream(new FileOutputStream(inputDir
                    + "/fcs.bin"));

            for (int i = 0; i < markers; i++) {
                for (int j = 0; j < events; j++) {
                    binFile.writeInt(values[i][j]);
                }
            }
            binFile.close();
        } catch (Exception ex) {
            System.out.println("EX: " + ex);
            throw new Exception("Problem generating the fcs.bin file");
        } finally {
            if (fcsReader != null) {
                try {
                    fcsReader.close();
                } catch (IOException e) {

                }
            }
            if (binFile != null) {
                try {
                    binFile.close();
                } catch (IOException e) {

                }
            }
        }
    }

    /**
     * Generate overview images.
     * 
     * @param inputDir
     *            the input dir
     * @throws Exception
     *             the exception
     */
    private void genOverviewImages(File inputDir) throws Exception {
        FlowImageGenerator fig = new FlowImageGenerator(0l, inputDir, inputDir);
        String parametersFile = inputDir + "/fcs.properties";
        fig.processParameters(parametersFile);
        fig.getAllCoordinatesFast(300);
        fig.getPopulationsFast();
        fig.genOverviewImages(300, false);
        fig.genOverviewImages(300, true);
    }

    /**
     * Write bin.
     * 
     * @param events
     *            the events
     * @param markers
     *            the markers
     * @param fileDir
     *            the file dir
     */
    private void writeBin(int events, int markers, File fileDir) {
        String exprFile = fileDir + "/fcs.bin";
        FileInputStream expr = null;
        int[][] coordinates = new int[events][markers];

        try {
            expr = new FileInputStream(new File(exprFile));
            FileChannel exprChannel = expr.getChannel();
            int size = (int) exprChannel.size();
            MappedByteBuffer exprByteBuffer1 = exprChannel.map(
                    FileChannel.MapMode.READ_ONLY, 0, size);

            for (int i = 0; i < markers; i++) {
                for (int j = 0; j < events; j++) {
                    coordinates[j][i] = exprByteBuffer1.getInt();
                }
            }

            PrintWriter pw = new PrintWriter(new File(fileDir + "/fcs.text"));
            for (int i = 0; i < events; i++) {
                for (int j = 0; j < markers; j++) {
                    if (j < (markers - 1)) {
                        pw.print(coordinates[i][j] + "\t");
                    } else {
                        pw.print(coordinates[i][j] + "\n");
                    }
                }
            }
            pw.close();

        } catch (Exception ex) {
            System.out.println("Ex: " + ex);
            return;
        } finally {
            if (expr != null) {
                try {
                    expr.close();
                } catch (Exception e) {

                }
            }
        }
    }

    /**
     * The main method.
     * 
     * @param args
     *            the arguments
     */
    public static void main(String[] args) {
        if (args.length != 1) {
            System.err.print("Task Directory must be specified");
            return;
        }
        String baseDirStr = args[0];
        File baseDir = new File(baseDirStr);

        ConvertTaskToBinary ctb = new ConvertTaskToBinary();

        String[] fileDirectories = baseDir.list();
        List<String> list = Arrays.asList(fileDirectories);
        Collections.sort(list);

        for (String fileDirectory : list) {
            System.out.println("FileName: " + fileDirectory);
            File f = new File(baseDirStr + "/" + fileDirectory);
            if (f.isDirectory()) {
                System.out.println("Working in directory " + f);
                try {
                    int events = ctb.getEventsCount(f);
                    String[] parameters = ctb.getParameters(f);
                    System.out.println("      Events: " + events);
                    System.out.println("         Min: " + parameters[0]);
                    System.out.println("         Max: " + parameters[1]);
                    System.out.println("        Bins: " + parameters[2]);
                    System.out.println("     Density: " + parameters[3]);

                    ArrayList<String> markers = ctb.getMarkerNames(f);
                    System.out.println("     Markers: " + markers.size());
                    StringBuffer markersStr = new StringBuffer();
                    for (String markerName : markers) {
                        markersStr.append(markerName + "|");
                    }
                    markersStr.deleteCharAt(markersStr.length() - 1); // remove
                    // ending
                    // |

                    int populationCount = ctb.getPopulationCount(f);

                    PrintWriter pw = new PrintWriter(f + "/" + "fcs.properties");
                    pw.print("Min=" + parameters[0] + "\n");
                    pw.print("Max=" + parameters[1] + "\n");
                    pw.print("Events=" + events + "\n");
                    pw.print("Bins=" + parameters[2] + "\n");
                    pw.print("Density=" + parameters[3] + "\n");
                    pw.print("Markers=" + markers.size() + "\n");
                    pw.print("MarkerNames=" + markersStr + "\n");
                    pw.print("Populations=" + populationCount + "\n");
                    pw.close();

                    /*
                     * Delete all the PNG files
                     */
                    /*
                     * Don't delete images right now ImageFileFilter iff =
                     * ctb.new ImageFileFilter(); File[] pngFiles =
                     * ff.listFiles(iff); for (File pngFile : pngFiles) {
                     * pngFile.delete(); //System.out.println("file: " +
                     * pngFile.getName()); }
                     */

                    ctb.genPopulationBin(f);
                    ctb.genFcsBin(f, markers.size(), events);
                    // ctb.writeBin(events,markers.size(),f);
                    ctb.genOverviewImages(f);
                } catch (Exception ex) {
                    System.out.println("      EX: " + ex);
                    continue;
                }

            }
        }

    }

    /**
     * A class that implements the Java FileFilter interface.
     *
     * @author BISC-Team
     */
    private class ImageFileFilter implements FileFilter {

        /** The ok file extensions. */
        private final String[] okFileExtensions = new String[] { "png" };

        /*
         * (non-Javadoc)
         * 
         * @see java.io.FileFilter#accept(java.io.File)
         */
        public boolean accept(File file) {
            for (String extension : okFileExtensions) {
                if (file.getName().toLowerCase().endsWith(extension)) {
                    return true;
                }
            }
            return false;
        }
    }

}
