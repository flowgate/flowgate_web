package org.immport.struts.utils.flow;

import java.util.ArrayList;

/**
 * The Class Profile.
 *
 * @author BISC-Team
 */
public class Profile {
	
	/** The populations. */
	private ArrayList <Population> populations = null;
	
	/** The markers. */
	private ArrayList <Marker> markers = null;
	
	/**
	 * Gets the populations.
	 *
	 * @return the populations
	 */
	public ArrayList<Population> getPopulations() {
		return populations;
	}
	
	/**
	 * Sets the populations.
	 *
	 * @param populations the new populations
	 */
	public void setPopulations(ArrayList<Population> populations) {
		this.populations = populations;
	}
	
	/**
	 * Gets the markers.
	 *
	 * @return the markers
	 */
	public ArrayList<Marker> getMarkers() {
		return markers;
	}
	
	/**
	 * Sets the markers.
	 *
	 * @param markers the new markers
	 */
	public void setMarkers(ArrayList<Marker> markers) {
		this.markers = markers;
	}

	/**
	 * Find population.
	 *
	 * @param popId the pop id
	 * @return the population
	 */
	public Population findPopulation(Byte popId) {
		for (Population pop: populations) {
			if (popId == pop.getPopulation()) {
				return pop;
			}
		}
		return null;
	}
}
