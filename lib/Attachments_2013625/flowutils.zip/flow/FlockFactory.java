package org.immport.struts.utils.flow;

/**
 * A factory for creating Flock objects.
 */
public class FlockFactory {

    /** The instance. */
    private static FlockAdapter instance;

    /**
     * Gets the single instance of FlockFactory.
     * 
     * @return single instance of FlockFactory
     * @throws InstantiationException
     *             the instantiation exception
     * @throws IllegalAccessException
     *             the illegal access exception
     * @throws ClassNotFoundException
     *             the class not found exception
     */
    public static FlockAdapter getInstance() throws InstantiationException,
            IllegalAccessException, ClassNotFoundException {
        if (instance == null) {
            // ResourceBundle rb =
            // ResourceBundle.getBundle("org.immport.struts.utils.flow.flow");
            // String classname = rb.getString("adapter");
            // Changed to Hard Code 11/5/2009 - JCampbell, May want to re-adjust
            // later
            String classname = "org.immport.struts.utils.flow.FlockAdapterFile";
            instance = (FlockAdapter) Class.forName(classname).newInstance();
        }
        return instance;
    }

    /**
     * The main method.
     * 
     * @param args
     *            the arguments
     * @throws Exception
     *             the exception
     */
    public static void main(String[] args) throws Exception {
        System.out.print(FlockFactory.getInstance());
    }
}
