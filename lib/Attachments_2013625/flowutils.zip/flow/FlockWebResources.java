package org.immport.struts.utils.flow;

import java.util.ResourceBundle;

/**
 * Singleton resource bundle reader.
 *
 * @author BISC-Team
 */
public class FlockWebResources extends Object {

	/** The only instance of this class. */
	private static FlockWebResources instance = null;

	/** Bundle of data to read from. */
	private ResourceBundle bundle = null;

	/**
	 * Private constructor to fulfill Singleton pattern.
	 */
	private FlockWebResources() {
		bundle = ResourceBundle
				.getBundle("org.immport.struts.utils.flow.FlockWebResources");
	}

	/**
	 * Instance retriever.
	 * 
	 * @return The single static instance of this class.
	 */
	public static FlockWebResources getInstance() {
		if (instance == null) {
			instance = new FlockWebResources();
		}
		return instance;
	}

	/**
	 * Retrieve a value from the resources file mapping to a given key.
	 * 
	 * @param in
	 *            String key
	 * @return String value
	 */
	public String getString(String in) {
		return bundle.getString(in);
	}

}
