package org.immport.struts.utils.flow;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.imageio.ImageIO;

import org.apache.commons.io.IOUtils;

/**
 * The Class FlowImageGenerator.
 *
 * @author BISC-Team
 */
public class FlowImageGenerator {
	
	/** The task id. */
	private long taskId;
	
	/** The input dir. */
	private File inputDir;
	
	/** The output dir. */
	private File outputDir;
	
	/** The parameters. */
	private Properties parameters;

	/** The coordinates. */
	private int[][] coordinates;
	
	/** The populations. */
	private int[] populations;
	
	/** The events color. */
	private Color[] eventsColor;
	
	/** The population ids. */
	private Integer[] populationIds;

	/**
	 * Instantiates a new flow image generator.
	 */
	public FlowImageGenerator() {
	}

	/**
	 * Instantiates a new flow image generator.
	 *
	 * @param taskId the task id
	 * @param inputDir the input dir
	 * @param outputDir the output dir
	 * @throws Exception the exception
	 */
	public FlowImageGenerator(long taskId, File inputDir, File outputDir)
			throws Exception {
		this.taskId = taskId;
		this.inputDir = inputDir;
		this.outputDir = outputDir;
	}
	
	/*
	 * Read in the fcs.properties file and load a Properties object.
	 */
	/**
	 * Process parameters.
	 *
	 * @param fileName the file name
	 * @throws Exception the exception
	 */
	public void processParameters(String fileName) throws Exception {
		parameters = new Properties();
		try {
			parameters.load(new FileInputStream(fileName));
		} catch (IOException e) {
			throw new Exception("Unable to load the parameters file");
		}
	}
	
	/**
	 * Process profile.
	 *
	 * @param fileName the file name
	 * @throws Exception the exception
	 */
	public void processProfile(String fileName) throws Exception {
			List<Integer> list = new ArrayList<Integer>();
			BufferedReader br = null;
			String line;
			try {
				br = new BufferedReader(new FileReader(new File(fileName)));
				br.readLine();// skip first line
				while ((line = br.readLine()) != null) {
					String[] ss = line.split("\t");
					if (ss[0] != null) {
						list.add(Integer.valueOf(ss[0]));
					}
				}
			} catch (IOException e) {
				throw new FlockAdapterException(e);
			} finally {
				try {
					if (br != null) {
						br.close();
					}
				} catch (IOException e) {
					throw new FlockAdapterException(e);
				}
			}

			populationIds = (Integer[])list.toArray(new Integer[list.size()]); 
		}

	/**
	 * Gen props file.
	 *
	 * @param inputDir the input dir
	 * @throws Exception the exception
	 */
	public void genPropsFile(File inputDir) throws Exception {
		List<Integer> list = new ArrayList<Integer>();
		BufferedReader br = null;
		PrintWriter pw = null;
		String line;
		try {
			pw = new PrintWriter(new File(inputDir + "/props"));
			br = new BufferedReader(new FileReader(new File(inputDir + "/profile.txt")));
			line = br.readLine();
			String [] markerNames = line.split("\t");
			while ((line = br.readLine()) != null) {
				StringBuffer str = new StringBuffer();
				String [] data = line.split("\t");
				str.append("markerExpression" + data[0] + "=");
				for (int i = 1; i < data.length; i++) {
					str.append(markerNames[i]);
					str.append(trans.get(data[i]));				
				}
				pw.println(str.toString());
			}
		} catch (IOException e) {
			throw new Exception(e);
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					throw new Exception(e);
				}
			}
			if (pw != null) {
				try {
					pw.close();
				} catch (Exception e) {
					throw new Exception(e);
				}
			}
		}
	}

	/** The Constant trans. */
	private static final Map<String,String> trans = new HashMap <String,String>();
	static{
		{
			trans.put("1", "-");
			trans.put("2", "lo");
			trans.put("3", "+");
			trans.put("4", "hi");
		}
	}

	/*
	 * Used for debugging, to make sure proper parameters are available
	 */
	/**
	 * Prints the parameters.
	 */
	private void printParameters() {
		for (Enumeration e = parameters.keys(); e.hasMoreElements();) {
			String key = (String) e.nextElement();
			System.out.println(key + "=" + parameters.getProperty(key));
		}
	}
	
	/*
	 * Read in the coordinates matrix from the binary version of the FCS file
	 * As the coordinates are read in, transform them into the proper range
	 * based on the dimension parameter.
	 * 
	 * The binary version of the FCS file is layed out with markers as the
	 * row and each event is a column. This makes it quicker when the program
	 * only needs to access the information for 2 markers, as is the case in
	 * other methods.
	 * 
	 * The last row of the binary version of the FCS file contains the populations
	 * assigned to each event.
	 */
	/**
	 * Gets the all coordinates fast.
	 *
	 * @param dimension the dimension
	 * @return the all coordinates fast
	 */
	public void getAllCoordinatesFast(int dimension) {
		int events = Integer.parseInt(parameters.getProperty("Events"));
		int markers = Integer.parseInt(parameters.getProperty("Markers"));
		float min = Float.parseFloat(parameters.getProperty("Min"));
		float max = Float.parseFloat(parameters.getProperty("Max"));
		float range = max - min + 1;
		String exprFile = inputDir.getAbsolutePath() + "/fcs.bin";
		FileInputStream expr = null;

		coordinates = new int[events][markers];

		try {
			expr = new FileInputStream(new File(exprFile));
			FileChannel exprChannel = expr.getChannel();
			int size = (int) exprChannel.size();
			MappedByteBuffer exprByteBuffer = exprChannel.map(
					FileChannel.MapMode.READ_ONLY, 0, size);
			exprByteBuffer.position(0);

			for (int i = 0; i < markers; i++) {
				for (int j = 0; j < events; j++) {
					float value = (float) exprByteBuffer.getInt();
					coordinates[j][i] = (int)(((value - min) * dimension)/ range);
				}
			}

		} catch (Exception ex) {
			System.out.println("Ex: " + ex);
			return;
		} finally {
			if (expr != null) {
				try {
					expr.close();
				} catch (Exception e) {

				}
			}
		}
	}
	
	/*
	 * Fill in the coorinates array with expression values for only 2 markers
	 */
	/**
	 * Gets the marker coordinates fast.
	 *
	 * @param dimension the dimension
	 * @param marker1 the marker1
	 * @param marker2 the marker2
	 * @return the marker coordinates fast
	 */
	public void getMarkerCoordinatesFast(int dimension, int marker1,int marker2) {
		int events = Integer.parseInt(parameters.getProperty("Events"));
		int markers = Integer.parseInt(parameters.getProperty("Markers"));
		float min = Float.parseFloat(parameters.getProperty("Min"));
		float max = Float.parseFloat(parameters.getProperty("Max"));
		float range = max - min + 1;
		String exprFile = inputDir.getAbsolutePath() + "/fcs.bin";
		FileInputStream expr = null;
		coordinates = new int[events][markers];

		try {
			expr = new FileInputStream(new File(exprFile));
			FileChannel exprChannel = expr.getChannel();
			int size = (int) exprChannel.size();
			MappedByteBuffer exprByteBuffer1 = exprChannel.map(
					FileChannel.MapMode.READ_ONLY, 0, size);
			MappedByteBuffer exprByteBuffer2 = exprChannel.map(
					FileChannel.MapMode.READ_ONLY, 0, size);

			int pos1 = marker1 * events * 4;
			int pos2 = marker2 * events * 4;
			exprByteBuffer1.position(pos1);
			exprByteBuffer2.position(pos2);

			for (int j = 0; j < events; j++) {
				float value1 = (float) exprByteBuffer1.getInt();
				coordinates[j][marker1] = (int) (((value1 - min) * dimension) / range);
				float value2 = (float) exprByteBuffer2.getInt();
				coordinates[j][marker2] = (int) (((value2 - min) * dimension) / range);
			}

		} catch (Exception ex) {
			System.out.println("Ex: " + ex);
			return;
		} finally {
			if (expr != null) {
				try {
					expr.close();
				} catch (Exception e) {

				}
			}
		}
	}


	/*
	 * This method is used to testing the loading of coordinates.
	 * It prints out the values for the first 10 events for 2 markers
	 */
	/**
	 * Prints the coordinates.
	 *
	 * @param marker1 the marker1
	 * @param marker2 the marker2
	 */
	public void printCoordinates(int marker1, int marker2) {
		for (int i = 0; i < 10; i++) {
			System.out.println(coordinates[i][marker1] + "\t"
					+ coordinates[i][marker2]);
		}
	}
	
	/*
	 * The population.bin file is a binary version of the population_id.txt file
	 * It is packed in as a binary file for quicker access.
	 */
	/**
	 * Gets the populations fast.
	 *
	 * @return the populations fast
	 */
	public void getPopulationsFast() {
		int events = Integer.parseInt(parameters.getProperty("Events"));
		String exprFile = inputDir.getAbsolutePath() + "/population.bin";
		FileInputStream expr = null;
		populations = new int[events];

		try {
			expr = new FileInputStream(new File(exprFile));
			FileChannel exprChannel = expr.getChannel();
			int size = (int) exprChannel.size();
			MappedByteBuffer exprByteBuffer = exprChannel.map(
					FileChannel.MapMode.READ_ONLY, 0, size);
			int pos = 0;
			exprByteBuffer.position(pos);

			for (int j = 0; j < events; j++) {
				populations[j] = exprByteBuffer.getInt();
			}
		} catch (Exception ex) {
			System.out.println("Ex: " + ex);
			return;
		} finally {
			if (expr != null) {
				try {
					expr.close();
				} catch (Exception e) {

				}
			}
		}
	}
	
	/*
	 * Generates individual images for each Marker vs Marker combination. The
	 * files can represent the all.color or all.bw images. In previous versions of
	 * this code we used the marker names to create the file names. This can be a
	 * problem if the marker names use special characters like "/" etc. So now the
	 * file names are use m1, m2 etc for the marker names.
	 */
	/**
	 * Gen overview images.
	 *
	 * @param dimension the dimension
	 * @param bw the bw
	 */
	public void genOverviewImages(int dimension, boolean bw) {
		System.out.println("Starting genOverviewImages");
		int markers = Integer.parseInt(parameters.getProperty("Markers"));
		String markerStr = parameters.getProperty("MarkerNames");
		String [] markerNames = markerStr.split("\\|");

		long startTime = System.currentTimeMillis();
		try {

			for (int i = 0; i < markers; i++) {
				for (int j = 0; j < markers; j++) {
					String name1 = "m" + i;
					String name2 = "m" + j;
					//String name1 = markerNames[i];
					//String name2 = markerNames[j];
					String imageName = null;
					if (bw) {
						imageName = name1 + "." + name2 + ".all.bw.png";
					} else {
						imageName = name1 + "." + name2 + ".all.color.png";
					}
					BufferedImage img = new BufferedImage(dimension, dimension,
							BufferedImage.TYPE_INT_RGB);
					Graphics2D g2d = img.createGraphics();
					g2d.setColor(Color.LIGHT_GRAY);
					g2d.fillRect(0, 0, dimension, dimension);

					Color[][] imageMatrix = genImageMatrix(dimension, i, j);

					for (int k = 0; k < dimension; k++) {
						for (int l = 0; l < dimension; l++) {
							if (imageMatrix[k][l] != null) {
								if (bw) {
									g2d.setColor(Color.BLACK);
								} else {
									g2d.setColor(imageMatrix[k][l]);
								}
								g2d.drawLine(k, l, k, l);
							}
						}
					}

					if (name1.equals(name2)) {
						byte[] b4 = generateSolidImage(dimension, dimension);

						saveDotPlotImage(imageName, new ByteArrayInputStream(b4));
					} else {

						byte[] allPopColor = getImageAsByteArray(img);
						saveDotPlotImage(imageName, new ByteArrayInputStream(
								allPopColor));

					}
				}
			}

		} catch (Exception e) {
			System.out.println("E: " + e);
		}
		long stopTime = System.currentTimeMillis();
		System.out
				.println("genOverviewImages " + (stopTime - startTime) / 1000);

	}
	
	/**
	 * Gen marker2 marker images.
	 *
	 * @param dimension the dimension
	 * @param idx1 the idx1
	 * @param idx2 the idx2
	 * @throws Exception the exception
	 */
	public void genMarker2MarkerImages(int dimension, int idx1, int idx2) throws Exception {
		String markerStr = parameters.getProperty("MarkerNames");
		String [] markerNames = markerStr.split("\\|");
		try {
			for (int i = 0; i < populationIds.length; i++) {
				int pop = populationIds[i];
				//String name1 = markerNames[idx1];
				//String name2 = markerNames[idx2];
				String name1 = "m" + idx1;
				String name2 = "m" + idx2;
				String imageName = name1 + "." + name2+ "." + pop + ".color.highlighted.png";
				BufferedImage img = new BufferedImage(dimension, dimension,
						BufferedImage.TYPE_INT_RGB);
				Graphics2D g2d = img.createGraphics();
				g2d.setColor(Color.LIGHT_GRAY);
				g2d.fillRect(0, 0, dimension, dimension);

				Color[][] imageMatrix = genImageMatrixPop(dimension, idx1, idx2, pop);

				for (int k = 0; k < dimension; k++) {
					for (int l = 0; l < dimension; l++) {
						if (imageMatrix[k][l] != null) {
							g2d.setColor(imageMatrix[k][l]);
							g2d.drawLine(k, l, k, l);
						}
					}
				}
				if (name1.equals(name2)) {
					byte[] b4 = generateSolidImage(dimension, dimension);
					saveDotPlotImage(imageName, new ByteArrayInputStream(b4));
				} else {

					byte[] allPopColor = getImageAsByteArray(img);
					saveDotPlotImage(imageName, new ByteArrayInputStream(
							allPopColor));

				}
			}
		} catch (Exception e) {
			System.out.println("E: " + e);
			throw new Exception(e);
		}

	}
	
	/**
	 * Gen marker2 marker2 pop images.
	 *
	 * @param dimension the dimension
	 * @param idx1 the idx1
	 * @param idx2 the idx2
	 * @param pop the pop
	 * @throws Exception the exception
	 */
	public void genMarker2Marker2PopImages(int dimension, int idx1, int idx2, int pop) throws Exception {
		String markerStr = parameters.getProperty("MarkerNames");
		String [] markerNames = markerStr.split("\\|");
		try {
				//String name1 = markerNames[idx1];
				//String name2 = markerNames[idx2];
				String name1 = "m" + idx1;
				String name2 = "m" + idx2;
				String imageName = name1 + "." + name2+ "." + pop + ".color.highlighted.png";
				BufferedImage img = new BufferedImage(dimension, dimension,
						BufferedImage.TYPE_INT_RGB);
				Graphics2D g2d = img.createGraphics();
				g2d.setColor(Color.LIGHT_GRAY);
				g2d.fillRect(0, 0, dimension, dimension);

				Color[][] imageMatrix = genImageMatrixPop(dimension, idx1, idx2, pop);

				for (int k = 0; k < dimension; k++) {
					for (int l = 0; l < dimension; l++) {
						if (imageMatrix[k][l] != null) {
							g2d.setColor(imageMatrix[k][l]);
							g2d.drawLine(k, l, k, l);
						}
					}
				}
				if (name1.equals(name2)) {
					byte[] b4 = generateSolidImage(dimension, dimension);
					saveDotPlotImage(imageName, new ByteArrayInputStream(b4));
				} else {

					byte[] allPopColor = getImageAsByteArray(img);
					saveDotPlotImage(imageName, new ByteArrayInputStream(
							allPopColor));

				}
		} catch (Exception e) {
			System.out.println("E: " + e);
			throw new Exception(e);
		}
	}
	
	/*
	 * For 2 markers generate a matrix of normally 300 by 300, which each
	 * spot assigned a color based on the population number
	 */
	/**
	 * Gen image matrix.
	 *
	 * @param dimension the dimension
	 * @param idx1 the idx1
	 * @param idx2 the idx2
	 * @return the color[][]
	 */
	public Color[][] genImageMatrix(int dimension, int idx1, int idx2) {
		Color[][] imageMatrix = new Color[dimension][dimension];
		int events = Integer.parseInt(parameters.getProperty("Events"));
		for (int i = 0; i < events; i++) {
			int x = coordinates[i][idx1];
			int y = dimension - coordinates[i][idx2];

			Color c = ColorUtils.getColor(populations[i]);

			if (x == dimension) {
				x = dimension - 1;
			}
			if (y == dimension) {
				y = dimension - 1;
			}

			imageMatrix[x][y] = c;
		}
		return imageMatrix;

	}
	
	/*
	 * For 2 markers generate a matrix, with only one population colored,
	 * The rest of the populations are colored white.
	 */
	/**
	 * Gen image matrix pop.
	 *
	 * @param dimension the dimension
	 * @param idx1 the idx1
	 * @param idx2 the idx2
	 * @param pop the pop
	 * @return the color[][]
	 */
	public Color[][] genImageMatrixPop(int dimension, int idx1, int idx2, int pop) {
		Color[][] imageMatrix = new Color[dimension][dimension];
		int events = Integer.parseInt(parameters.getProperty("Events"));
		/*
		 * First color all events white
		 */
		for (int i = 0; i < events; i++) {
			int x = coordinates[i][idx1];
			int y = dimension - coordinates[i][idx2];

			Color c = Color.white;

			if (x == dimension) {
				x = dimension - 1;
			}
			if (y == dimension) {
				y = dimension - 1;
			}

			imageMatrix[x][y] = c;
		}
		
		/*
		 * Now color in the events for this population
		 */
		Color c = ColorUtils.getColor(pop);
		for (int i = 0; i < events; i++) {
			if (pop == populations[i]) {
				int x = coordinates[i][idx1];
				int y = dimension - coordinates[i][idx2];

				if (x == dimension) {
					x = dimension - 1;
				}
				if (y == dimension) {
					y = dimension - 1;
				}

				imageMatrix[x][y] = c;
			} 
		}
		
		return imageMatrix;
	}
	
	/**
	 * Generate solid image.
	 *
	 * @param width the width
	 * @param height the height
	 * @return the byte[]
	 * @throws Exception the exception
	 */
	private byte[] generateSolidImage(int width, int height) throws Exception {
		BufferedImage img = new BufferedImage(width, height,
				BufferedImage.TYPE_INT_RGB);
		Graphics2D g2d = img.createGraphics();
		g2d.setColor(Color.GRAY);
		g2d.fillRect(0, 0, width, height);

		return getImageAsByteArray(img);
	}

	/**
	 * Gets the image as byte array.
	 *
	 * @param img the img
	 * @return the image as byte array
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private byte[] getImageAsByteArray(BufferedImage img) throws IOException {
		// save as a GIF file
		ByteArrayOutputStream image = new ByteArrayOutputStream();
		ImageIO.write(img, "png", image);
		image.close();
		return image.toByteArray();
	}

	/**
	 * Save dot plot image.
	 *
	 * @param name the name
	 * @param is the is
	 * @throws Exception the exception
	 */
	public void saveDotPlotImage(String name, InputStream is) throws Exception {
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(outputDir, name));
			IOUtils.copy(is, fos);
			fos.close();
		} catch (FileNotFoundException ex) {
			System.out.println("Ex: " + ex);
		} catch (IOException ex) {
			System.out.println("Ex: " + ex);
		} finally {
			try {
				if (fos != null) {
					fos.close();
				}
			} catch (IOException ex) {
				System.out.println("Ex: " + ex);
			}
		}

	}
	
	/**
	 * The main method.
	 *
	 * @param args the arguments
	 * @throws Exception the exception
	 */
	public static void main(String[] args) throws Exception {

		/*
		 * This program generates images for visualisation of Flow analysis
		 * Different command types require different command line parameters
		 * 
		 * Parameter 1: indicates which types of images to generate
		 * 	overview - generates images for each marker by marker combination, both in color and black and white
		 *  overview_color - generate images for each marker by marker combination in color
		 *  overview_bw - generate images for each marker by marker combination in black and white
		 *  marker_by_marker_pop - generates images for a marker by marker combination and all po
		 * Parameter 2: the dimension of the image. Standard is 300X300
		 * Parameter 3: location of the input directory
		 * Parameter 4: location of the output directory
		 * Parameter 5,6 If Parameter 1 is marker_by_marker_pop then these parameters are the indexes of the 2 markers
		 * Parameter 7 If Parameter 1 is maker_by_marker_pop, then this parameter is the population id
		 */
		StringBuffer usage = new StringBuffer("Usage:\n");
		usage.append("  Command: [overview, overview_color, marker_by_marker, marker_by_marker_by_pop\n");
		usage.append("   Dimension - most images use 300 to indicate 300x300\n");
		usage.append("   Input Directory\n");
		usage.append("   Output Directory\n");
		usage.append("   Index of Marker 1\n");
		usage.append("   Index of Marker 2\n");
		usage.append("   Population id\n");
		if (args.length != 4 && args.length != 5 && args.length != 6 && args.length != 7) {	
			System.err.print(usage.toString());
			return;
		}
		long startTime = System.currentTimeMillis();
		String type = args[0];
		Integer dimension = Integer.parseInt(args[1]);
		File inputDir = new File(args[2]);
		File outputDir = new File(args[3]);
		String parametersFile = args[2] + "/fcs.properties";

		FlowImageGenerator fig = new FlowImageGenerator(0l, inputDir,outputDir);
		fig.processParameters(parametersFile);
		//fig.printParameters();
		
		if (type.equals("overview")) {
			fig.getAllCoordinatesFast(dimension);
			//fig.printCoordinates(0,1);
			fig.getPopulationsFast();
			fig.genOverviewImages(300, false);
			fig.genOverviewImages(300, true);
		} else if (type.equals("marker_by_marker")) {
			int index1 = Integer.parseInt(args[4]);
			int index2 = Integer.parseInt(args[5]);
			fig.processProfile(args[2] + "/profile.txt");
			fig.getMarkerCoordinatesFast(dimension, index1, index2);
			fig.getPopulationsFast();
			//fig.printCoordinates(index1,index2);
			fig.genMarker2MarkerImages(dimension,index1,index2);
		} else if (type.equals("marker_by_marker_by_pop")) {
			int index1 = Integer.parseInt(args[4]);
			int index2 = Integer.parseInt(args[5]);
			int popId = Integer.parseInt(args[6]);
			fig.processProfile(args[2] + "/profile.txt");
			fig.getMarkerCoordinatesFast(dimension, index1, index2);
			fig.getPopulationsFast();
			//fig.printCoordinates(index1,index2);
			fig.genMarker2Marker2PopImages(dimension,index1,index2, popId);
		} else {
			System.err.print(usage.toString());
			return;
		}
		
		long stopTime = System.currentTimeMillis();
		System.out.println("Finished FlowImageGeneration " + (stopTime - startTime));
	}
}
