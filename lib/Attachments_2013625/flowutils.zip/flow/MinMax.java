package org.immport.struts.utils.flow;

/**
 * The Class MinMax.
 *
 * @author BISC-Team
 */
public class MinMax {
	
	/** The max x. */
	int maxX = Integer.MIN_VALUE;
	
	/** The max y. */
	int maxY = Integer.MIN_VALUE;
	
	/** The min x. */
	int minX = Integer.MAX_VALUE;
	
	/** The min y. */
	int minY = Integer.MAX_VALUE;
	
	/**
	 * Gets the max x.
	 *
	 * @return the max x
	 */
	public int getMaxX() {
		return maxX;
	}
	
	/**
	 * Sets the max x.
	 *
	 * @param maxX the new max x
	 */
	public void setMaxX(int maxX) {
		this.maxX = maxX;
	}
	
	/**
	 * Gets the max y.
	 *
	 * @return the max y
	 */
	public int getMaxY() {
		return maxY;
	}
	
	/**
	 * Sets the max y.
	 *
	 * @param maxY the new max y
	 */
	public void setMaxY(int maxY) {
		this.maxY = maxY;
	}
	
	/**
	 * Gets the min x.
	 *
	 * @return the min x
	 */
	public int getMinX() {
		return minX;
	}
	
	/**
	 * Sets the min x.
	 *
	 * @param minX the new min x
	 */
	public void setMinX(int minX) {
		this.minX = minX;
	}
	
	/**
	 * Gets the min y.
	 *
	 * @return the min y
	 */
	public int getMinY() {
		return minY;
	}
	
	/**
	 * Sets the min y.
	 *
	 * @param minY the new min y
	 */
	public void setMinY(int minY) {
		this.minY = minY;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return("minX="+minX+" maxX="+maxX+" minY="+minY+" maxY="+maxY);
	}
}
