package org.immport.struts.utils.flow;

/**
 * The Class Marker.
 *
 * @author BISC-Team
 */
public class Marker {
	
	/** The name. */
	private String name;
	
	/** The index. */
	private int index;
	
	/**
	 * Instantiates a new marker.
	 */
	public Marker() {}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the index.
	 *
	 * @return the index
	 */
	public int getIndex() {
		return index;
	}

	/**
	 * Sets the index.
	 *
	 * @param index the new index
	 */
	public void setIndex(int index) {
		this.index = index;
	};
}
