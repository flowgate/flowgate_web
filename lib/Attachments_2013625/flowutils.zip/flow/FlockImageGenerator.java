package org.immport.struts.utils.flow;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;

import org.apache.commons.io.IOUtils;

/**
 * Generate flock images
 *
 * @author BISC-Team
 */
public class FlockImageGenerator {

    /** The task id. */
    private long taskId;

    /** The input dir. */
    private File inputDir;

    /** The output dir. */
    private File outputDir;

    /** The adapter. */
    private FlockAdapter adapter;

    /** The profile. */
    Profile profile = null;

    /** The markers. */
    List<Marker> markers = null;

    /** The populations. */
    List<Population> populations = null;

    /** The min max. */
    MinMax minMax = null;

    /** The events. */
    byte[] events;

    /** The coordinates. */
    int[][] coordinates;

    /** The centroids. */
    int[][] centroids;

    /**
     * Instantiates a new flock image generator.
     */
    public FlockImageGenerator() {
    }

    /**
     * Instantiates a new flock image generator.
     * 
     * @param taskId
     *            the task id
     * @param inputDir
     *            the input dir
     * @param outputDir
     *            the output dir
     * @throws Exception
     *             the exception
     */
    public FlockImageGenerator(long taskId, File inputDir, File outputDir)
            throws Exception {
        this(taskId, inputDir, outputDir, FlockFactory.getInstance());
    }

    /**
     * Instantiates a new flock image generator.
     * 
     * @param taskId
     *            the task id
     * @param inputDir
     *            the input dir
     * @param outputDir
     *            the output dir
     * @param adapter
     *            the adapter
     */
    public FlockImageGenerator(long taskId, File inputDir, File outputDir,
            FlockAdapter adapter) {
        this.taskId = taskId;
        this.inputDir = inputDir;
        this.outputDir = outputDir;
        this.adapter = adapter;
        PoorMansTable dbmock = new PoorMansTable(outputDir);
        adapter.setInputDir(inputDir);
        adapter.setOutputDir(outputDir);
        adapter.setDbmock(dbmock);
    }

    /*
     * Process the profile.txt, percentage.txt and population_center.txt files
     * The information in these files is transferred to the Profile data
     * structure.
     * 
     * Also calculates the min and max values in the coordinates.txt file. And
     * loads this file into the coordinates vector
     * 
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    public void processFlockOutput() throws FlockAdapterException {
        long startTime = System.currentTimeMillis();
        try {
            profile = adapter.getProfile();
            markers = profile.getMarkers();
            populations = profile.getPopulations();
            // minMax = adapter.getMinMaxAll();
            // System.out.println("minX: " + minMax.getMinX());
            // System.out.println("minY: " + minMax.getMinY());
            // System.out.println("maxX: " + minMax.getMaxX());
            // System.out.println("maxY: " + minMax.getMaxY());
            minMax = adapter.getMinMaxFile();
            // System.out.println("minX: " + minMax.getMinX());
            // System.out.println("minY: " + minMax.getMinY());
            // System.out.println("maxX: " + minMax.getMaxX());
            // System.out.println("maxY: " + minMax.getMaxY());
            events = adapter.getEvents();
            coordinates = adapter.getCoordinates(events.length, markers.size());

        } catch (Exception e) {
            System.out.println("E: " + e);
            throw new FlockAdapterException(e);
        }
        long stopTime = System.currentTimeMillis();
        System.out.println("ProcessFlockOutput: " + (stopTime - startTime)
                / 1000);
    }

    /**
     * Generate props file.
     *
     * @throws FlockAdapterException the flock adapter exception
     */
    public void genPropsFile() throws FlockAdapterException {
        profile = adapter.getProfile();
        markers = profile.getMarkers();
        populations = profile.getPopulations();

        for (int i = 0; i < populations.size(); i++) {
            Population pop = populations.get(i);
            Byte popId = pop.getPopulation();
            ArrayList<Integer> scores = pop.getScores();

            StringBuffer sb = new StringBuffer();

            for (int j = 0; j < markers.size(); j++) {
                String markerName = markers.get(j).getName();
                int index = markers.get(j).getIndex();
                sb.append(markerName).append(trans.get(scores.get(index)));
            }

            adapter.savePopulationMarkerExpression(0, (int) popId, sb
                    .toString());

        }

    }

    /*
     * Generates individual images for each Marker vs Marker combination. The
     * files can represent the all.color or all.bw images
     *
     * @param width the width
     * @param height the height
     * @param bw the bw
     * @throws FlockAdapterException the flock adapter exception
     */
    /**
     * Generate overview images.
     *
     * @param width the width
     * @param height the height
     * @param bw the bw
     * @throws FlockAdapterException the flock adapter exception
     */
    public void genOverviewImages(int width, int height, boolean bw)
            throws FlockAdapterException {

        int numMarkers = markers.size();

        long startTime = System.currentTimeMillis();
        try {

            for (int i = 0; i < numMarkers; i++) {
                for (int j = 0; j < numMarkers; j++) {
                    int idx1 = markers.get(i).getIndex();
                    String name1 = markers.get(i).getName();
                    int idx2 = markers.get(j).getIndex();
                    String name2 = markers.get(j).getName();
                    String imageName = null;
                    if (bw) {
                        imageName = name1 + "." + name2 + ".all.bw.png";
                    } else {
                        imageName = name1 + "." + name2 + ".all.color.png";
                    }
                    BufferedImage img = new BufferedImage(width, height,
                            BufferedImage.TYPE_INT_RGB);
                    Graphics2D g2d = img.createGraphics();
                    g2d.setColor(Color.LIGHT_GRAY);
                    g2d.fillRect(0, 0, width, height);

                    FlockEvents flockEvents = genEventsMatrix(width, height,
                            idx1, idx2);
                    Color[][] allEvents = flockEvents.getAllEvents();

                    for (int k = 0; k < height; k++) {
                        for (int l = 0; l < height; l++) {
                            if (allEvents[k][l] != null) {
                                if (bw) {
                                    g2d.setColor(Color.BLACK);
                                } else {
                                    g2d.setColor(allEvents[k][l]);
                                }
                                g2d.drawLine(k, l, k, l);
                            }
                        }
                    }

                    if (name1.equals(name2)) {
                        byte[] b4 = generateSolidImage(300, 300);
                        adapter.saveDotPlotImage(imageName,
                                new ByteArrayInputStream(b4));
                    } else {

                        // File outputfile = new File(outputDir,imageName);
                        // ImageIO.write(img, "png", outputfile);

                        byte[] allPopColor = getImageAsByteArray(img);
                        adapter.saveDotPlotImage(imageName,
                                new ByteArrayInputStream(allPopColor));

                    }
                }
            }

        } catch (Exception e) {
            System.out.println("E: " + e);
            throw new FlockAdapterException(e);
        }
        long stopTime = System.currentTimeMillis();
        System.out
                .println("genOverviewImages " + (stopTime - startTime) / 1000);

    }

    /*
     * Generates individual images for each Marker vs Marker combination. The
     * files can represent the all.color or all.bw images
     * 
     * @param width
     *            the width
     * @param height
     *            the height
     * @param bw
     *            the bw
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    /**
     * Generate marker by marker images.
     *
     * @param width the width
     * @param height the height
     * @param bw the bw
     * @throws FlockAdapterException the flock adapter exception
     */
    public void genMarkerByMarkerImages(int width, int height, boolean bw)
            throws FlockAdapterException {

        int numMarkers = markers.size();

        long startTime = System.currentTimeMillis();
        try {

            for (int i = 0; i < numMarkers; i++) {
                for (int j = 0; j < numMarkers; j++) {
                    long startMarkerTime = System.currentTimeMillis();
                    int idx1 = markers.get(i).getIndex();
                    String name1 = markers.get(i).getName();
                    int idx2 = markers.get(j).getIndex();
                    String name2 = markers.get(j).getName();
                    String imageName = null;
                    if (bw) {
                        imageName = name1 + "." + name2 + ".all.bw.png";
                    } else {
                        imageName = name1 + "." + name2 + ".all.color.png";
                    }
                    BufferedImage img = new BufferedImage(width, height,
                            BufferedImage.TYPE_INT_RGB);
                    Graphics2D g2d = img.createGraphics();
                    g2d.setColor(Color.LIGHT_GRAY);
                    g2d.fillRect(0, 0, width, height);

                    FlockEvents flockEvents = genEventsMatrix(width, height,
                            idx1, idx2);
                    Color[][] allEvents = flockEvents.getAllEvents();
                    // Map<Byte, boolean[][]> popEvents = flockEvents
                    // .getPopEvents();

                    for (int k = 0; k < height; k++) {
                        for (int l = 0; l < height; l++) {
                            if (allEvents[k][l] != null) {
                                if (bw) {
                                    g2d.setColor(Color.BLACK);
                                } else {
                                    g2d.setColor(allEvents[k][l]);
                                }
                                g2d.drawLine(k, l, k, l);
                            }
                        }
                    }

                    /*
                     * int min = minMax.getMinX(); int maxX = minMax.getMaxX();
                     * int max = (int) (((float) maxX/4095f) * 300); int range =
                     * max - min;
                     * 
                     * for (int k = 0; k < events.length; k++) { //int xValue =
                     * coordinates[k][idx1]; //int yValue = max -
                     * coordinates[k][idx2]; int x = coordinates[k][idx1]; int y
                     * = max - coordinates[k][idx2];
                     * 
                     * //System.out.println("X: " + x);
                     * //System.out.println("Y: " + y);
                     * //System.out.println("Max: " + max);
                     * 
                     * //int x = (int) (((xValue - min)/range) * 300f); //int y
                     * = (int) (((max - yValue)/range) * 300f);
                     * 
                     * //Color c = ColorUtils.getColor(events[k]);
                     * g2d.setColor(ColorUtils.getColor(events[k]));
                     * 
                     * if (x == width) { x = width - 1; } if (y == height) { y =
                     * height - 1; } g2d.drawLine(x,y,x,y);
                     * 
                     * }
                     */

                    if (name1.equals(name2)) {
                        byte[] b4 = generateSolidImage(300, 300);
                        adapter.saveDotPlotImage(imageName,
                                new ByteArrayInputStream(b4));
                    } else {

                        // File outputfile = new File(outputDir,imageName);
                        // ImageIO.write(img, "png", outputfile);

                        byte[] allPopColor = getImageAsByteArray(img);
                        adapter.saveDotPlotImage(imageName,
                                new ByteArrayInputStream(allPopColor));

                    }
                    long stopMarkerTime = System.currentTimeMillis();
                    System.out.println("Marker " + i + " " + j + " "
                            + (stopMarkerTime - startMarkerTime) / 1000);
                }
            }

        } catch (Exception e) {
            System.out.println("E: " + e);
            throw new FlockAdapterException(e);
        }
        long stopTime = System.currentTimeMillis();
        System.out.println("genMarkerByMarkerImages TEST "
                + (stopTime - startTime) / 1000);

    }

    /*
     * For a single population, generate images representing all the marker
     * combination.
     * 
     * @param popId
     *            the pop id
     * @param width
     *            the width
     * @param height
     *            the height
     * @param bw
     *            the bw
     * @param highlighted
     *            the highlighted
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    /**
     * Generate single population.
     *
     * @param popId the pop id
     * @param width the width
     * @param height the height
     * @param bw the bw
     * @param highlighted the highlighted
     * @throws FlockAdapterException the flock adapter exception
     */
    public void genSinglePopulation(Byte popId, int width, int height,
            boolean bw, boolean highlighted) throws FlockAdapterException {

        int numMarkers = markers.size();

        long startTime = System.currentTimeMillis();
        try {

            for (int i = 0; i < numMarkers; i++) {
                for (int j = 0; j < numMarkers; j++) {

                    int idx1 = markers.get(i).getIndex();
                    String name1 = markers.get(i).getName();
                    int idx2 = markers.get(j).getIndex();
                    String name2 = markers.get(j).getName();

                    FlockEvents flockEvents = genEventsMatrix(width, height,
                            idx1, idx2);
                    Color[][] allEvents = flockEvents.getAllEvents();
                    Map<Byte, boolean[][]> popEvents = flockEvents
                            .getPopEvents();

                    String imageName = "";
                    if (highlighted) {
                        imageName = name1 + "." + name2 + "." + popId
                                + ".color.highlighted.png";

                        if (name1.equals(name2)) {
                            byte[] b4 = generateSolidImage(300, 300);
                            adapter.saveDotPlotImage(imageName,
                                    new ByteArrayInputStream(b4));
                        } else {
                            byte[] b4 = generatePopHighlighted(allEvents,
                                    popEvents.get(popId), ColorUtils
                                            .getColor(popId), bw);

                            adapter.saveDotPlotImage(imageName,
                                    new ByteArrayInputStream(b4));
                        }

                    } else {
                        imageName = name1 + "." + name2 + "." + popId
                                + ".color.only.png";

                        if (name1.equals(name2)) {
                            byte[] b4 = generateSolidImage(300, 300);
                            adapter.saveDotPlotImage(imageName,
                                    new ByteArrayInputStream(b4));
                        } else {
                            byte[] b4 = generatePopColorOnly(allEvents,
                                    popEvents.get(popId), ColorUtils
                                            .getColor(popId), bw);

                            adapter.saveDotPlotImage(imageName,
                                    new ByteArrayInputStream(b4));
                        }
                    }

                }
            }

        } catch (Exception e) {
            System.out.println("E: " + e);
            throw new FlockAdapterException(e);
        }
        long stopTime = System.currentTimeMillis();
        System.out.println("genSinglePopulation " + (stopTime - startTime)
                / 1000);

    }

    /*
     * For every population and every marker combination, create an image
     * 
     * @param width
     *            the width
     * @param height
     *            the height
     * @param bw
     *            the bw
     * @param highlighted
     *            the highlighted
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    /**
     * Generate marker by marker populations.
     *
     * @param width the width
     * @param height the height
     * @param bw the bw
     * @param highlighted the highlighted
     * @throws FlockAdapterException the flock adapter exception
     */
    public void genMarkerByMarkerPopulations(int width, int height, boolean bw,
            boolean highlighted) throws FlockAdapterException {

        int numMarkers = markers.size();

        long startTime = System.currentTimeMillis();
        try {

            for (int i = 0; i < numMarkers; i++) {
                for (int j = 0; j < numMarkers; j++) {

                    int idx1 = markers.get(i).getIndex();
                    String name1 = markers.get(i).getName();
                    int idx2 = markers.get(j).getIndex();
                    String name2 = markers.get(j).getName();

                    FlockEvents flockEvents = genEventsMatrix(width, height,
                            idx1, idx2);
                    Color[][] allEvents = flockEvents.getAllEvents();
                    Map<Byte, boolean[][]> popEvents = flockEvents
                            .getPopEvents();
                    for (Population population : populations) {
                        Byte popId = population.getPopulation();
                        String imageName = "";
                        if (highlighted) {
                            imageName = name1 + "." + name2 + "." + popId
                                    + ".color.highlighted.png";

                            if (name1.equals(name2)) {
                                byte[] b4 = generateSolidImage(300, 300);
                                adapter.saveDotPlotImage(imageName,
                                        new ByteArrayInputStream(b4));
                            } else {
                                byte[] b4 = generatePopHighlighted(allEvents,
                                        popEvents.get(popId), ColorUtils
                                                .getColor(popId), bw);

                                adapter.saveDotPlotImage(imageName,
                                        new ByteArrayInputStream(b4));
                            }

                        } else {
                            imageName = name1 + "." + name2 + "." + popId
                                    + ".color.only.png";

                            if (name1.equals(name2)) {
                                byte[] b4 = generateSolidImage(300, 300);
                                adapter.saveDotPlotImage(imageName,
                                        new ByteArrayInputStream(b4));
                            } else {
                                byte[] b4 = generatePopColorOnly(allEvents,
                                        popEvents.get(popId), ColorUtils
                                                .getColor(popId), bw);

                                adapter.saveDotPlotImage(imageName,
                                        new ByteArrayInputStream(b4));
                            }
                        }
                    }

                }
            }

        } catch (Exception e) {
            System.out.println("E: " + e);
            throw new FlockAdapterException(e);
        }
        long stopTime = System.currentTimeMillis();
        System.out.println("genMarkerByMarkerPopulations "
                + (stopTime - startTime) / 1000);

    }

    /*
     * For 2 markers, create all the images for every population
     * 
     * @param index1
     *            the index1
     * @param index2
     *            the index2
     * @param width
     *            the width
     * @param height
     *            the height
     * @param bw
     *            the bw
     * @param highlighted
     *            the highlighted
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    /**
     * Generate marker2 marker populations.
     *
     * @param index1 the index1
     * @param index2 the index2
     * @param width the width
     * @param height the height
     * @param bw the bw
     * @param highlighted the highlighted
     * @throws FlockAdapterException the flock adapter exception
     */
    public void genMarker2MarkerPopulations(int index1, int index2, int width,
            int height, boolean bw, boolean highlighted)
            throws FlockAdapterException {

        long startTime = System.currentTimeMillis();
        try {

            int idx1 = markers.get(index1).getIndex();
            String name1 = markers.get(index1).getName();
            int idx2 = markers.get(index2).getIndex();
            String name2 = markers.get(index2).getName();

            FlockEvents flockEvents = genEventsMatrixPop(width, height, idx1,
                    idx2);
            Color[][] allEvents = flockEvents.getAllEvents();
            Map<Byte, boolean[][]> popEvents = flockEvents.getPopEvents();
            for (Population population : populations) {
                Byte popId = population.getPopulation();
                String imageName = "";
                if (highlighted) {
                    imageName = name1 + "." + name2 + "." + popId
                            + ".color.highlighted.png";

                    if (name1.equals(name2)) {
                        byte[] b4 = generateSolidImage(300, 300);
                        adapter.saveDotPlotImage(imageName,
                                new ByteArrayInputStream(b4));
                    } else {
                        byte[] b4 = generatePopHighlighted(allEvents, popEvents
                                .get(popId), ColorUtils.getColor(popId), bw);

                        adapter.saveDotPlotImage(imageName,
                                new ByteArrayInputStream(b4));
                    }

                } else {
                    imageName = name1 + "." + name2 + "." + popId
                            + ".color.only.png";

                    if (name1.equals(name2)) {
                        byte[] b4 = generateSolidImage(300, 300);
                        adapter.saveDotPlotImage(imageName,
                                new ByteArrayInputStream(b4));
                    } else {
                        byte[] b4 = generatePopColorOnly(allEvents, popEvents
                                .get(popId), ColorUtils.getColor(popId), bw);

                        adapter.saveDotPlotImage(imageName,
                                new ByteArrayInputStream(b4));
                    }
                }

            }

        } catch (Exception e) {
            System.out.println("E: " + e);
            throw new FlockAdapterException(e);
        }
        long stopTime = System.currentTimeMillis();
        System.out.println("genMarker2MarkerPopulations "
                + (stopTime - startTime) / 1000);

    }

    /**
     * Generate events matrix.
     *
     * @param width the width
     * @param height the height
     * @param idx1 the idx1
     * @param idx2 the idx2
     * @return the flock events
     */
    private FlockEvents genEventsMatrix(int width, int height, int idx1,
            int idx2) {

        FlockEvents flockEvents = new FlockEvents();
        Color[][] allEvents = new Color[width][height];
        // Map<Byte, boolean[][]> popEvents = new HashMap<Byte, boolean[][]>();
        // for (Population population : populations) {
        // popEvents.put(population.getPopulation(),
        // new boolean[width][height]);
        // }

        /*
         * float minX = minMax.getMinX(); float maxX = minMax.getMaxX(); float
         * range = maxX - minX;
         * 
         * int max = (int) ((maxX/range) * 300);
         */
        int max = 299;

        for (int k = 0; k < events.length; k++) {
            int x = coordinates[k][idx1];
            int y = max - coordinates[k][idx2];

            Color c = ColorUtils.getColor(events[k]);

            if (x == width) {
                x = width - 1;
            }
            if (y == height) {
                y = height - 1;
            }

            allEvents[x][y] = c;
            // popEvents.get(events[k])[x][y] = true;
        }
        flockEvents.setAllEvents(allEvents);
        // flockEvents.setPopEvents(popEvents);

        return flockEvents;
    }

    /**
     * Generate events matrix population.
     *
     * @param width the width
     * @param height the height
     * @param idx1 the idx1
     * @param idx2 the idx2
     * @return the flock events
     */
    private FlockEvents genEventsMatrixPop(int width, int height, int idx1,
            int idx2) {

        FlockEvents flockEvents = new FlockEvents();
        Color[][] allEvents = new Color[width][height];
        Map<Byte, boolean[][]> popEvents = new HashMap<Byte, boolean[][]>();
        for (Population population : populations) {
            popEvents.put(population.getPopulation(),
                    new boolean[width][height]);
        }

        int max = 299;

        for (int k = 0; k < events.length; k++) {
            int x = coordinates[k][idx1];
            int y = max - coordinates[k][idx2];

            Color c = ColorUtils.getColor(events[k]);

            if (x == width) {
                x = width - 1;
            }
            if (y == height) {
                y = height - 1;
            }

            allEvents[x][y] = c;
            popEvents.get(events[k])[x][y] = true;
        }
        flockEvents.setAllEvents(allEvents);
        flockEvents.setPopEvents(popEvents);

        return flockEvents;
    }

    /**
     * Gets the image as byte array.
     * 
     * @param img
     *            the img
     * @return the image as byte array
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    private byte[] getImageAsByteArray(BufferedImage img) throws IOException {
        // save as a GIF file
        ByteArrayOutputStream image = new ByteArrayOutputStream();
        ImageIO.write(img, "png", image);
        image.close();
        return image.toByteArray();
    }

    /**
     * Generate solid image.
     * 
     * @param width
     *            the width
     * @param height
     *            the height
     * @return the byte[]
     * @throws Exception
     *             the exception
     */
    private byte[] generateSolidImage(int width, int height) throws Exception {

        BufferedImage img = new BufferedImage(width, height,
                BufferedImage.TYPE_INT_RGB);

        Graphics2D g2d = img.createGraphics();
        g2d.setColor(Color.GRAY);
        g2d.fillRect(0, 0, width, height);

        return getImageAsByteArray(img);
    }

    /**
     * Generate highlighted population.
     * 
     * @param allEvents
     *            the all events
     * @param popEvents
     *            the pop events
     * @param c
     *            the color
     * @param bw
     *            the bw flag
     * @return the byte[]
     * @throws Exception
     *             the exception
     */
    private byte[] generatePopHighlighted(Color[][] allEvents,
            boolean[][] popEvents, Color c, boolean bw) throws Exception {

        int width = popEvents.length;
        int height = popEvents[0].length;

        BufferedImage img = new BufferedImage(width, height,
                BufferedImage.TYPE_INT_RGB);

        Graphics2D g2d = img.createGraphics();
        g2d.setColor(Color.LIGHT_GRAY);
        g2d.fillRect(0, 0, width, height);
        g2d.setColor(Color.WHITE);
        // draw background
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                if (allEvents[i][j] != null) {
                    g2d.drawLine(i, j, i, j);
                }
            }
        }

        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                if (popEvents[i][j]) {
                    if (bw) {
                        g2d.setColor(Color.BLACK);
                    } else {
                        g2d.setColor(c);
                    }
                    g2d.drawLine(i, j, i, j);
                }
            }
        }

        return getImageAsByteArray(img);
    }

    /**
     * Generate pop color only.
     * 
     * @param allEvents
     *            the all events
     * @param popEvents
     *            the pop events
     * @param c
     *            the c
     * @param bw
     *            the bw
     * @return the byte[]
     * @throws Exception
     *             the exception
     */
    private byte[] generatePopColorOnly(Color[][] allEvents,
            boolean[][] popEvents, Color c, boolean bw) throws Exception {

        int width = popEvents.length;
        int height = popEvents[0].length;

        BufferedImage img = new BufferedImage(width, height,
                BufferedImage.TYPE_INT_RGB);

        Graphics2D g2d = img.createGraphics();
        g2d.setColor(Color.LIGHT_GRAY);
        g2d.fillRect(0, 0, width, height);

        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                if (popEvents[i][j]) {
                    if (bw) {
                        g2d.setColor(Color.BLACK);
                    } else {
                        g2d.setColor(c);
                    }
                    g2d.drawLine(i, j, i, j);
                }
            }
        }

        return getImageAsByteArray(img);
    }

    /*
     * THIS IS PROTOTYPE CODE AND NOT CURRENTLY USED Tries to generate one image
     * that contains all marker combinations May be more effiecent than
     * generating many images, but needs to use SPRITE technology on UI size to
     * extract individual images.
     * 
     * @param fileName
     *            the file name
     * @param width
     *            the width
     * @param height
     *            the height
     * @param bw
     *            the bw
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    /**
     * Generate marker by marker image.
     *
     * @param fileName the file name
     * @param width the width
     * @param height the height
     * @param bw the bw
     * @throws FlockAdapterException the flock adapter exception
     */
    public void genMarkerByMarkerImage(String fileName, int width, int height,
            boolean bw) throws FlockAdapterException {

        int numMarkers = markers.size();
        int rectSize = numMarkers * height;
        BufferedImage img = new BufferedImage(rectSize, rectSize,
                BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = img.createGraphics();
        g2d.setColor(Color.LIGHT_GRAY);
        g2d.fillRect(0, 0, rectSize, rectSize);

        long startTime = System.currentTimeMillis();
        try {
            FileOutputStream fos = new FileOutputStream(new File(outputDir,
                    fileName));

            for (int i = 0; i < numMarkers; i++) {
                for (int j = 0; j < numMarkers; j++) {

                    int idx1 = markers.get(i).getIndex();
                    int idx2 = markers.get(j).getIndex();

                    FlockEvents flockEvents = genEventsMatrix(width, height,
                            idx1, idx2);
                    Color[][] allEvents = flockEvents.getAllEvents();
                    Map<Byte, boolean[][]> popEvents = flockEvents
                            .getPopEvents();

                    for (int k = 0; k < height; k++) {
                        for (int l = 0; l < height; l++) {
                            if (allEvents[k][l] != null) {
                                if (bw) {
                                    g2d.setColor(Color.BLACK);
                                } else {
                                    g2d.setColor(allEvents[k][l]);
                                }
                                g2d.drawLine(i * height + k, j * height + l, i
                                        * height + k, j * height + l);
                            }
                        }
                    }
                }
            }

            byte[] allPopColor = getImageAsByteArray(img);
            IOUtils.copy(new ByteArrayInputStream(allPopColor), fos);
            fos.close();

        } catch (Exception e) {
            System.out.println("E: " + e);
            throw new FlockAdapterException(e);
        }
        long stopTime = System.currentTimeMillis();
        System.out.println("genMarkerByMarkerImage " + (stopTime - startTime)
                / 1000);

    }

    /** The Constant trans. */
    private static final Map<Integer, String> trans = new HashMap();
    static {
        {
            trans.put(1, "-");
            trans.put(2, "lo");
            trans.put(3, "+");
            trans.put(4, "hi");
        }
    }

    /**
     * The main method.
     * 
     * @param args
     *            the arguments
     * @throws Exception
     *             the exception
     */
    public static void main(String[] args) throws Exception {

        if (args.length != 3 && args.length != 4 && args.length != 5) {
            throw new Exception(
                    "Usage: command <Type: single_image, all_images, all_populations, marker_populations single_population> <INPUT_DIR> <OUTPUT_DIR> [Index 1] [Index 2]");
        }
        String type = args[0];
        File inputDir = new File(args[1]);
        File outputDir = new File(args[2]);

        FlockImageGenerator fig = new FlockImageGenerator(0l, inputDir,
                outputDir);

        fig.processFlockOutput();

        if (type.equals("all_images")) {
            // fig.genMarkerByMarkerImages(300, 300, false);
            // fig.genMarkerByMarkerImages(300, 300, true);
            // fig.genMarkerByMarkerPopulations(300, 300, false,true);
            // fig.genMarkerByMarkerPopulations(300, 300, false,false);
        } else if (type.equals("overview")) {
            fig.genOverviewImages(300, 300, false);
            fig.genOverviewImages(300, 300, true);
        } else if (type.equals("overview_color")) {
            fig.genOverviewImages(300, 300, false);
        } else if (type.equals("overview_bw")) {
            fig.genOverviewImages(300, 300, true);
        } else if (type.equals("all_markers")) {
            fig.genMarkerByMarkerImages(300, 300, false);
        } else if (type.equals("all_populations")) {
            fig.genMarkerByMarkerPopulations(300, 300, false, true);
        } else if (type.equals("marker_populations")) {
            if (args.length != 5) {
                System.err
                        .println("For type 'marker_populations, you must provide index1 and index2");
                throw new Exception(
                        "Usage: command <Type: single_image, all_markers, all_populations, marker_populations> <INPUT_DIR> <OUTPUT_DIR> [Index 1] [Index 2]");
            }
            int index1 = Integer.parseInt(args[3]);
            int index2 = Integer.parseInt(args[4]);

            fig.genMarker2MarkerPopulations(index1, index2, 300, 300, false,
                    true);
        } else if (type.equals("single_population")) {
            if (args.length != 4) {
                System.err
                        .println("For type 'single_population, you must provide popIdx");
                throw new Exception(
                        "Usage: command <Type: single_image, all_images, all_populations, marker_populations, single_population> <INPUT_DIR> <OUTPUT_DIR> [Index 1] [Index 2] [popIdx]");
            }
            Byte index1 = Byte.parseByte(args[3]);

            fig.genSinglePopulation(index1, 300, 300, false, true);
        } else if (type.equals("gen_propsfile")) {
            fig.genPropsFile();
        } else {
            System.err.println("Not a valid type");
            throw new Exception(
                    "Usage: command <Type: single_image, all_images, all_populations, marker_populations> <INPUT_DIR> <OUTPUT_DIR> [Index 1] [Index 2]");
        }

    }

    /*
     * For a single population, generate images representing all the marker
     * combination.
     * 
     * @param popId
     *            the pop id
     * @param m1
     *            the m1
     * @param m2
     *            the m2
     * @param width
     *            the width
     * @param height
     *            the height
     * @param bw
     *            the bw
     * @param highlighted
     *            the highlighted
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    /**
     * Generate pop by marker.
     *
     * @param popId the pop id
     * @param m1 the m1
     * @param m2 the m2
     * @param width the width
     * @param height the height
     * @param bw the bw
     * @param highlighted the highlighted
     * @throws FlockAdapterException the flock adapter exception
     */
    public void genPopByMarker(Byte popId, int m1, int m2, int width,
            int height, boolean bw, boolean highlighted)
            throws FlockAdapterException {

        System.out.println("PopId: " + popId + " m1: " + m1 + " m2: " + m2);
        long startTime = System.currentTimeMillis();
        try {
            int idx1 = markers.get(m1).getIndex();
            String name1 = markers.get(m1).getName();
            int idx2 = markers.get(m2).getIndex();
            String name2 = markers.get(m2).getName();

            FlockEvents flockEvents = genEventsMatrixPop(width, height, idx1,
                    idx2);

            Color[][] allEvents = flockEvents.getAllEvents();
            Map<Byte, boolean[][]> popEvents = flockEvents.getPopEvents();

            String imageName = "";
            if (highlighted) {
                imageName = name1 + "." + name2 + "." + popId
                        + ".color.highlighted.png";

                if (name1.equals(name2)) {
                    byte[] b4 = generateSolidImage(300, 300);
                    adapter.saveDotPlotImage(imageName,
                            new ByteArrayInputStream(b4));
                } else {
                    byte[] b4 = generatePopHighlighted(allEvents, popEvents
                            .get(popId), ColorUtils.getColor(popId), bw);

                    adapter.saveDotPlotImage(imageName,
                            new ByteArrayInputStream(b4));
                }

            } else {
                imageName = name1 + "." + name2 + "." + popId
                        + ".color.only.png";

                if (name1.equals(name2)) {
                    byte[] b4 = generateSolidImage(300, 300);
                    adapter.saveDotPlotImage(imageName,
                            new ByteArrayInputStream(b4));
                } else {
                    byte[] b4 = generatePopColorOnly(allEvents, popEvents
                            .get(popId), ColorUtils.getColor(popId), bw);

                    adapter.saveDotPlotImage(imageName,
                            new ByteArrayInputStream(b4));
                }
            }

        } catch (Exception e) {
            System.out.println("E: " + e);
            throw new FlockAdapterException(e);
        }
        long stopTime = System.currentTimeMillis();
        System.out.println("genSinglePopulation " + (stopTime - startTime)
                / 1000);

    }

}
