package org.immport.struts.utils.flow;

import java.io.File;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * The Interface FlockAdapter.
 *
 * @author BISC-Team
 */
public interface FlockAdapter {

    /**
     * Sets the output dir.
     * 
     * @param outputDir
     *            the new output dir
     */
    public void setOutputDir(File outputDir);

    /**
     * Sets the input dir.
     * 
     * @param inputDir
     *            the new input dir
     */
    public void setInputDir(File inputDir);

    /**
     * Sets the dbmock.
     * 
     * @param dbmock
     *            the new dbmock
     */
    public void setDbmock(PoorMansTable dbmock);

    /**
     * Sets the output dir.
     * 
     * @param outputDir
     *            the new output dir
     */
    public void setOutputDir(String outputDir);

    /**
     * Sets the input dir.
     * 
     * @param inputDir
     *            the new input dir
     */
    public void setInputDir(String inputDir);

    /**
     * Sets the dbmock.
     * 
     * @param dbmock
     *            the new dbmock
     */
    public void setDbmock(String dbmock);

    /**
     * Gets the profile.
     * 
     * @return the profile
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    public Profile getProfile() throws FlockAdapterException;

    /**
     * Gets the min max all.
     * 
     * @return the min max all
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    public MinMax getMinMaxAll() throws FlockAdapterException;

    /**
     * Gets the min max file.
     * 
     * @return the min max file
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    public MinMax getMinMaxFile() throws FlockAdapterException;

    /**
     * Gets the events.
     * 
     * @return the events
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    public byte[] getEvents() throws FlockAdapterException;

    /**
     * Gets the coordinates.
     * 
     * @param x
     *            the x
     * @param y
     *            the y
     * @return the coordinates
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    public int[][] getCoordinates(int x, int y) throws FlockAdapterException;

    /**
     * Gets the centroids.
     * 
     * @param x
     *            the x
     * @param y
     *            the y
     * @return the centroids
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    public int[][] getCentroids(int x, int y) throws FlockAdapterException;

    /**
     * Gets the fcs properties.
     * 
     * @return the fcs properties
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    public Properties getFcsProperties() throws FlockAdapterException;

    /**
     * Save dot plot image.
     * 
     * @param dotPlotName
     *            the dot plot name
     * @param is
     *            the is
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    public void saveDotPlotImage(String dotPlotName, InputStream is)
            throws FlockAdapterException;

    /**
     * Gets the dimensions.
     * 
     * @param pid
     *            the pid
     * @return the dimensions
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    public String[] getDimensions(long pid) throws FlockAdapterException;

    /**
     * Gets the populations.
     * 
     * @param pid
     *            the pid
     * @return the populations
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    public List<Integer> getPopulations(long pid) throws FlockAdapterException;

    /**
     * Exists.
     * 
     * @param pid
     *            the pid
     * @param name
     *            the name
     * @return true, if successful
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    public boolean exists(long pid, String name) throws FlockAdapterException;

    /**
     * Load dot plot image.
     * 
     * @param pid
     *            the pid
     * @param name
     *            the name
     * @return the byte[]
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    public byte[] loadDotPlotImage(long pid, String name)
            throws FlockAdapterException;

    /**
     * Gets the percentage.
     * 
     * @param pid
     *            the pid
     * @return the percentage
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    public Map<Integer, Float> getPercentage(long pid)
            throws FlockAdapterException;

    /**
     * Gets the profile list.
     * 
     * @param pid
     *            the pid
     * @return the profile list
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    public List<String> getProfileList(long pid) throws FlockAdapterException;

    /**
     * Save population marker expression.
     * 
     * @param pid
     *            the pid
     * @param population
     *            the population
     * @param markerExpression
     *            the marker expression
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    public void savePopulationMarkerExpression(long pid, int population,
            String markerExpression) throws FlockAdapterException;

    /**
     * Save population cell type.
     * 
     * @param pid
     *            the pid
     * @param population
     *            the population
     * @param cellType
     *            the cell type
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    public void savePopulationCellType(long pid, int population, String cellType)
            throws FlockAdapterException;

    /**
     * Load population marker expression.
     * 
     * @param pid
     *            the pid
     * @param population
     *            the population
     * @return the string
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    public String loadPopulationMarkerExpression(long pid, int population)
            throws FlockAdapterException;

    /**
     * Load population cell type.
     * 
     * @param pid
     *            the pid
     * @param population
     *            the population
     * @return the string
     * @throws FlockAdapterException
     *             the flock adapter exception
     */
    public String loadPopulationCellType(long pid, int population)
            throws FlockAdapterException;

}
