package org.immport.struts.utils.flow;

/**
 * The FlockAdapterException Class.
 *
 * @author BISC-Team
 */
public class FlockAdapterException extends Exception {

    /**
     * Instantiates a new flock adapter exception.
     */
    public FlockAdapterException() {
    }

    /**
     * Instantiates a new flock adapter exception.
     * 
     * @param message
     *            the message
     */
    public FlockAdapterException(String message) {
        super(message);
    }

    /**
     * Instantiates a new flock adapter exception.
     * 
     * @param cause
     *            the cause
     */
    public FlockAdapterException(Throwable cause) {
        super(cause);
    }

    /**
     * Instantiates a new flock adapter exception.
     * 
     * @param message
     *            the message
     * @param cause
     *            the cause
     */
    public FlockAdapterException(String message, Throwable cause) {
        super(message, cause);
    }

}
