package org.immport.struts.utils.flow;

import java.awt.Color;
import java.util.Map;

/**
 * The Class FlockEvents.
 *
 * @author BISC-Team
 */
public class FlockEvents {

    /** The all events. */
    private Color[][] allEvents = null;

    /** The pop events. */
    private Map<Byte, boolean[][]> popEvents = null;

    /**
     * Gets the all events.
     * 
     * @return the all events
     */
    public Color[][] getAllEvents() {
        return allEvents;
    }

    /**
     * Sets the all events.
     * 
     * @param allEvents
     *            the new all events
     */
    public void setAllEvents(Color[][] allEvents) {
        this.allEvents = allEvents;
    }

    /**
     * Gets the pop events.
     * 
     * @return the pop events
     */
    public Map<Byte, boolean[][]> getPopEvents() {
        return popEvents;
    }

    /**
     * Sets the pop events.
     * 
     * @param popEvents
     *            the pop events
     */
    public void setPopEvents(Map<Byte, boolean[][]> popEvents) {
        this.popEvents = popEvents;
    }
}
