package org.immport.struts.utils.flow;

import java.util.ArrayList;

/**
 * The Class Population.
 *
 * @author BISC-Team
 */
public class Population {
	
	/** The population. */
	private Byte population;
	
	/** The percentage. */
	private Float percentage;
	
	/**
	 * Gets the percentage.
	 *
	 * @return the percentage
	 */
	public Float getPercentage() {
		return percentage;
	}

	/**
	 * Sets the percentage.
	 *
	 * @param percentage the new percentage
	 */
	public void setPercentage(Float percentage) {
		this.percentage = percentage;
	}

	/** The scores. */
	private ArrayList <Integer> scores = null;
	
	/** The centroids. */
	private ArrayList <Float> centroids = null;
	
	/** The mfis. */
	private ArrayList <Float> mfis = null;
	
	/**
	 * Gets the mfis.
	 *
	 * @return the mfis
	 */
	public ArrayList<Float> getMfis() {
		return mfis;
	}

	/**
	 * Sets the mfis.
	 *
	 * @param mfis the new mfis
	 */
	public void setMfis(ArrayList<Float> mfis) {
		this.mfis = mfis;
	}

	/**
	 * Gets the centroids.
	 *
	 * @return the centroids
	 */
	public ArrayList<Float> getCentroids() {
		return centroids;
	}

	/**
	 * Sets the centroids.
	 *
	 * @param centroids the new centroids
	 */
	public void setCentroids(ArrayList<Float> centroids) {
		this.centroids = centroids;
	}

	/**
	 * Instantiates a new population.
	 */
	public Population() {}

	/**
	 * Gets the population.
	 *
	 * @return the population
	 */
	public Byte getPopulation() {
		return population;
	}

	/**
	 * Sets the population.
	 *
	 * @param population the new population
	 */
	public void setPopulation(Byte population) {
		this.population = population;
	}

	/**
	 * Gets the scores.
	 *
	 * @return the scores
	 */
	public ArrayList<Integer> getScores() {
		return scores;
	}

	/**
	 * Sets the scores.
	 *
	 * @param scores the new scores
	 */
	public void setScores(ArrayList<Integer> scores) {
		this.scores = scores;
	};
	
}
